import {Component} from '@angular/core';
import {EmailValidator} from './validator/email.validator';
import {REACTIVE_FORM_DIRECTIVES, FormControl, FormGroup} from '@angular/forms';
@Component({
    selector: 'app-component',
    templateUrl: 'app/app.component.html',
    directives: [REACTIVE_FORM_DIRECTIVES,EmailValidator]
})
export class AppComponent {
  saveUser(f) {
    console.log(f);
  }
}
