"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var router_1 = require('@angular/router');
var http_client_1 = require('../core/http-client');
var LoginComponent = (function () {
    function LoginComponent(httpClient, router) {
        this.httpClient = httpClient;
        this.router = router;
        var accessToken = window.location.href.split(/=/);
        console.log(accessToken[1]);
        window.localStorage.setItem('access_token', accessToken[1]);
        console.log(window.localStorage.getItem('access_token'));
        //  this.access_token="cHJvamVjdENsaWVudDpwcm9qZWN0U2VjcmV0"
    }
    LoginComponent.prototype.ngOnInit = function () {
        this.accessTokenValidity();
    };
    LoginComponent.prototype.accessTokenValidity = function () {
        if (window.localStorage.getItem('access_token')) {
            this.router.navigate(['/timetrack/timesheet']);
        }
        else {
            this.accessTokenStorage();
        }
    };
    LoginComponent.prototype.accessTokenStorage = function () {
        if (this.access_token) {
            window.localStorage.setItem('access_token', this.access_token);
            this.router.navigate(['/timetrack/timesheet']);
        }
    };
    LoginComponent = __decorate([
        core_1.Component({
            selector: 'login-app',
            //templateUrl: './app/login/login.component.html'
            template: ''
        }), 
        __metadata('design:paramtypes', [http_client_1.HttpClient, router_1.Router])
    ], LoginComponent);
    return LoginComponent;
}());
exports.LoginComponent = LoginComponent;
//# sourceMappingURL=login.component.js.map