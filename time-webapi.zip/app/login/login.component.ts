import { Component } from '@angular/core';
import {Router,ActivatedRoute } from '@angular/router';
import {HttpClient} from '../core/http-client';

@Component({
    selector : 'login-app',
    //templateUrl: './app/login/login.component.html'
    template: ''
})

export class LoginComponent{
    private access_token:string;  
    constructor(private httpClient: HttpClient, private router: Router) {
        
        let accessToken = window.location.href.split(/=/);
        console.log(accessToken[1]);        
        window.localStorage.setItem('access_token', accessToken[1]);  
        console.log(window.localStorage.getItem('access_token'));
        
        
      //  this.access_token="cHJvamVjdENsaWVudDpwcm9qZWN0U2VjcmV0"
    }
    ngOnInit(){
        this.accessTokenValidity();
    }
    accessTokenValidity(){
        if (window.localStorage.getItem('access_token')) {
            this.router.navigate(['/timetrack/timesheet']);
        }
        else{
        this.accessTokenStorage();
            }
    }
    accessTokenStorage(){
        if(this.access_token){
            window.localStorage.setItem('access_token', this.access_token);
            this.router.navigate(['/timetrack/timesheet']);
        }
    }
    
}   