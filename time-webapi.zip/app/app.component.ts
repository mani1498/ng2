import { Component } from '@angular/core';
@Component({
    selector: 'ems',
    template: '<router-outlet></router-outlet>'
})
export class AppComponent { }
