"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var router_1 = require('@angular/router');
var http_client_1 = require('../core/http-client');
var LayoutComponent = (function () {
    function LayoutComponent(router, httpClient) {
        this.router = router;
        this.httpClient = httpClient;
        console.log(this.router.url);
        this.myroute = this.router.url.replace("/timetrack/", "");
    }
    LayoutComponent.prototype.getPosts = function () {
        var _this = this;
        this.httpClient
            .get('http://localhost:8081/atlis/timesheet/getUserProfile/2')
            .then(function (timeTrackHeaders) {
            _this.timeTrackHeaders = timeTrackHeaders;
        });
    };
    LayoutComponent.prototype.ngOnInit = function () {
        this.getPosts();
        this.getSideMenu();
    };
    LayoutComponent.prototype.getSideMenu = function () {
        var _this = this;
        if (window.localStorage.getItem('access_token')) {
            var userRole = 'employee';
            if (userRole == 'employee') {
                this.httpClient
                    .get('app/mock/user/employee/sideMenu.json')
                    .then(function (sidemenuObj) {
                    _this.sidemenuObj = sidemenuObj.clientResponse.roles;
                    console.log(_this.sidemenuObj);
                });
            }
        }
    };
    LayoutComponent = __decorate([
        core_1.Component({
            selector: 'layout',
            templateUrl: './app/layout/layout.component.html'
        }), 
        __metadata('design:paramtypes', [router_1.Router, http_client_1.HttpClient])
    ], LayoutComponent);
    return LayoutComponent;
}());
exports.LayoutComponent = LayoutComponent;
//# sourceMappingURL=layout.component.js.map