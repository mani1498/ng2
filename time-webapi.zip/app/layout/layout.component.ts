import { Component} from '@angular/core';
import { Router }            from '@angular/router';
import {HttpClient} from '../core/http-client';
@Component({
    selector: 'layout',
    templateUrl: './app/layout/layout.component.html'
})
export class LayoutComponent {
    public myroute: string;
    public sidemenuObj;
    public timeTrackHeaders;
    public timeTrackHeader;
    constructor(private router: Router, private httpClient: HttpClient) {
        console.log(this.router.url);
        this.myroute = this.router.url.replace("/timetrack/", "");
    }
    getPosts(): void {
        this.httpClient
            // .get('app/mock/header/timetrack-header.json')
            .get('http://localhost:8081/atlis/timesheet/getUserProfile/2')
            .then(timeTrackHeaders => {
                this.timeTrackHeaders = timeTrackHeaders;
            });
    }
    ngOnInit(): void {
        this.getPosts();
        this.getSideMenu();
    }

    getSideMenu(): void {
        if (window.localStorage.getItem('access_token')) {
            let userRole = 'employee';
            if (userRole == 'employee') {

                this.httpClient
                    .get('app/mock/user/employee/sideMenu.json')
                    .then(sidemenuObj => {
                        this.sidemenuObj = sidemenuObj.clientResponse.roles;

                        console.log(this.sidemenuObj);
                    });
            }
        }

    }
}