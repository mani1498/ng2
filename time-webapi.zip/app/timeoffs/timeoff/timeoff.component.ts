import { Component} from '@angular/core';
import {LazyLoadEvent} from "primeng/primeng";
import {HttpClient} from '../../core/http-client';
@Component({
    selector: 'timeoff',
    templateUrl: './app/timeoffs/timeoff/timeoff.component.html'
})
export class TimeoffComponent {
public posts;
    public post;
    public totalRecords:number=0;
    constructor(private httpClient: HttpClient) {
        this.totalRecords=100;
    }
    getPosts(): void {
        this.httpClient
            .get('app/mock/timeoff/timeoff-list.json')
            .then(posts => {
                this.posts = posts;
            });
    }
    ngOnInit(): void {
        this.getPosts();
    }
    loadCarsLazy(event: LazyLoadEvent) {
        //in a real application, make a remote request to load data using state metadata from event
        //event.first = First row offset
        //event.rows = Number of rows per page
        //event.sortField = Field name to sort with
        //event.sortOrder = Sort order as number, 1 for asc and -1 for dec
        //filters: FilterMetadata object having field as key and filter value, filter matchMode as value

        //imitate db connection over a network
        setTimeout(() => {
            console.log(event);
        }, 250);
    }
}
