import { ModuleWithProviders }  from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { TimeoffListComponent }  from './timeoff-list/timeoff-list.component';
import { TimeoffComponent }  from './timeoff/timeoff.component';
import { LayoutComponent }  from '../layout/layout.component';

const timeoffRoutes: Routes = [
    {
        path: '',
        component: LayoutComponent,
        children: [
            {
                path: 'timeoff',
                component: TimeoffComponent,
                children: [
                    {
                        path: '',
                        component: TimeoffListComponent
                    }
                ]
                
            }
        ]
    }
];

export const timeoffRouting: ModuleWithProviders = RouterModule.forChild(timeoffRoutes);