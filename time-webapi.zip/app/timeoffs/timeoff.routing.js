"use strict";
var router_1 = require('@angular/router');
var timeoff_list_component_1 = require('./timeoff-list/timeoff-list.component');
var timeoff_component_1 = require('./timeoff/timeoff.component');
var layout_component_1 = require('../layout/layout.component');
var timeoffRoutes = [
    {
        path: '',
        component: layout_component_1.LayoutComponent,
        children: [
            {
                path: 'timeoff',
                component: timeoff_component_1.TimeoffComponent,
                children: [
                    {
                        path: '',
                        component: timeoff_list_component_1.TimeoffListComponent
                    }
                ]
            }
        ]
    }
];
exports.timeoffRouting = router_1.RouterModule.forChild(timeoffRoutes);
//# sourceMappingURL=timeoff.routing.js.map