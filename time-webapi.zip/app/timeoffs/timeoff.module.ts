import { NgModule }      from '@angular/core';
import { CommonModule }       from '@angular/common';
import {ModalModule} from "ng2-modal";
import {DataTableModule,SharedModule} from 'primeng/primeng';
import {HttpClient} from '../core/http-client';

import { TimeoffListComponent }  from './timeoff-list/timeoff-list.component';
import { TimeoffComponent }  from './timeoff/timeoff.component';
import { timeoffRouting }  from './timeoff.routing';

@NgModule({
    imports:      [ CommonModule, ModalModule, timeoffRouting,
        DataTableModule,
        SharedModule ],
    declarations: [ TimeoffComponent,TimeoffListComponent ],
    providers: [
        HttpClient
    ]
})
export class TimeoffModule { }