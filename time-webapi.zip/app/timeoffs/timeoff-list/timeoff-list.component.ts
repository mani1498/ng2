import { Component} from '@angular/core';
@Component({
    selector: 'timeoff-list',
    template: ''
})
export class TimeoffListComponent {
}