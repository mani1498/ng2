import { ModuleWithProviders }  from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { TimesheetListComponent }  from './timesheet-list/timesheet-list.component';
import { TimesheetViewComponent }  from './timesheet-view/timesheet-view.component';
import { TimesheetComponent }  from './timesheet/timesheet.component';
import { LayoutComponent }  from '../layout/layout.component';

const timesheetRoutes: Routes = [
    {
        path: '',
        component: LayoutComponent,
        children: [
            {
                path: 'timesheet',
                component: TimesheetComponent,
                children: [
                    {
                        path: '',
                        component: TimesheetListComponent
                    }
                ]
            },
            {
                path: 'timesheet/view',
                component: TimesheetViewComponent,    
            }
        ]
    }
];

export const timesheetRouting: ModuleWithProviders = RouterModule.forChild(timesheetRoutes);