"use strict";
var router_1 = require('@angular/router');
var timesheet_list_component_1 = require('./timesheet-list/timesheet-list.component');
var timesheet_view_component_1 = require('./timesheet-view/timesheet-view.component');
var timesheet_component_1 = require('./timesheet/timesheet.component');
var layout_component_1 = require('../layout/layout.component');
var timesheetRoutes = [
    {
        path: '',
        component: layout_component_1.LayoutComponent,
        children: [
            {
                path: 'timesheet',
                component: timesheet_component_1.TimesheetComponent,
                children: [
                    {
                        path: '',
                        component: timesheet_list_component_1.TimesheetListComponent
                    }
                ]
            },
            {
                path: 'timesheet/view',
                component: timesheet_view_component_1.TimesheetViewComponent,
            }
        ]
    }
];
exports.timesheetRouting = router_1.RouterModule.forChild(timesheetRoutes);
//# sourceMappingURL=timesheet.routing.js.map