"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var http_client_1 = require('../../core/http-client');
var router_1 = require('@angular/router');
var TimesheetComponent = (function () {
    function TimesheetComponent(httpClient, router) {
        this.httpClient = httpClient;
        this.router = router;
        this.totalRecords = 0;
        this.totalRecords = 0;
        this.status = "NotSubmitted";
        this.startIndex = 0;
        this.results = 25;
        this.searchTerm = "";
        this.order = "desc";
        this.sortProperty = "status";
    }
    TimesheetComponent.prototype.getAllTimesheet = function (params) {
        var _this = this;
        this.httpClient
            .post('http://localhost:8081/atlis/timesheet/getTimesheetAll/', params)
            .then(function (timesheets) {
            _this.timesheets = timesheets.timesheetGridVO;
            _this.totalRecords = timesheets.totalRecords;
        });
    };
    TimesheetComponent.prototype.getTimesheetStatuses = function (params) {
        var _this = this;
        this.httpClient
            .post('http://localhost:8081/atlis/timesheet/getTimesheetStatuses/', params)
            .then(function (timeSheetHeaders) {
            _this.timeSheetHeaders = timeSheetHeaders;
            _this.overdueCount = timeSheetHeaders.overdueCount;
            _this.notSubmittedCount = timeSheetHeaders.notSubmittedCount;
            _this.rejectedCount = timeSheetHeaders.rejectedCount;
            _this.awaitingApprovalCount = timeSheetHeaders.awaitingApprovalCount;
            _this.approvedCount = timeSheetHeaders.approvedCount;
            _this.allCount = timeSheetHeaders.allCount;
        });
    };
    // Initialize the GRID Service  
    TimesheetComponent.prototype.getTimeSheetLists = function () {
        var params = {
            "employeeId": "4", "startDate": "", "endDate": "", "status": this.status, "searchTerm": this.searchTerm,
            "order": this.order, "startIndex": this.startIndex, "results": this.results, "sortProperty": this.sortProperty
        };
        this.getAllTimesheet(params);
    };
    TimesheetComponent.prototype.viewGridPagePost = function (gridpageValue) {
        console.log(gridpageValue);
        //awaiting
        //let params={"reqFrom":"web", "employeeId":"2", "timesheetId":"26", "startDate":"2016-08-01", "endDate":"2016-09-30"}
        //rejected
        //let params =  {"reqFrom":"web","employeeId":2, "timesheetId":3, "startDate":"2015-12-27", "endDate":"2016-01-02"};
        //overdue
        //let params = { "reqFrom":"web","employeeId": 4, "timesheetId": 13, "startDate": "2016-01-24", "endDate": "2016-01-30" };
        // not submitted
        var params = { "reqFrom": "web", "employeeId": gridpageValue.employeeId, "timesheetId": gridpageValue.timesheetId, "startDate": gridpageValue.startDate, "endDate": gridpageValue.endDate };
        localStorage.setItem("viewGridPostData", JSON.stringify(params));
        this.router.navigate(['/timetrack/timesheet/view']);
    };
    TimesheetComponent.prototype.ngOnInit = function () {
        var params = { "employeeId": "4", "startDate": "", "endDate": "" };
        this.getTimesheetStatuses(params);
    };
    TimesheetComponent.prototype.getTimesheetDetails = function (selectedDate) {
        this.convertedstartDate = this.dateconversion(selectedDate.start.replace(/^\s+|\s+$/g, ''));
        this.convertedendDate = this.dateconversion(selectedDate.end.replace(/^\s+|\s+$/g, ''));
        var params = { "employeeId": "4", "startDate": this.convertedstartDate, "endDate": this.convertedendDate };
        this.getTimesheetStatuses(params);
        var serviceRequestParams = {
            "employeeId": "4", "startDate": this.convertedstartDate, "endDate": this.convertedendDate, "status": this.status, "searchTerm": this.searchTerm,
            "order": this.order, "startIndex": this.startIndex, "results": this.results, "sortProperty": this.sortProperty
        };
        this.getAllTimesheet(serviceRequestParams);
    };
    TimesheetComponent.prototype.loadTimesheet = function (event) {
        //in a real application, make a remote request to load data using state metadata from event
        //event.first = First row offset
        //event.rows = Number of rows per page
        //event.sortField = Field name to sort with
        //event.sortOrder = Sort order as number, 1 for asc and -1 for dec
        //filters: FilterMetadata object having field as key and filter value, filter matchMode as value
        //imitate db connection over a network
        var _this = this;
        setTimeout(function () {
            if (_this.pickeddate) {
                var splitDate = _this.pickeddate.split(/-/);
                _this.convertedstartDate = _this.dateconversion(splitDate[0].replace(/^\s+|\s+$/g, ''));
                _this.convertedendDate = _this.dateconversion(splitDate[1].replace(/^\s+|\s+$/g, ''));
            }
            else {
                _this.convertedstartDate = "";
                _this.convertedendDate = "";
            }
            if (event.sortField)
                _this.sortProperty = event.sortField;
            if (event.page)
                _this.startIndex = event.page;
            if (event.sortField == 'status')
                _this.status = "All";
            var params = {
                "employeeId": "4", "startDate": _this.convertedstartDate, "endDate": _this.convertedendDate, "status": _this.status, "searchTerm": _this.searchTerm,
                "order": (event.sortOrder == 1) ? 'asc' : 'desc', "startIndex": _this.startIndex, "results": event.rows, "sortProperty": _this.sortProperty
            };
            _this.getAllTimesheet(params);
        }, 250);
    };
    TimesheetComponent.prototype.getStatusResults = function (status) {
        //	alert(status);
        this.status = status;
        var params = {
            "employeeId": "4", "startDate": this.convertedstartDate, "endDate": this.convertedendDate, "status": this.status, "searchTerm": "",
            "order": "desc", "startIndex": 0, "results": "25", "sortProperty": this.sortProperty
        };
        this.getAllTimesheet(params);
    };
    TimesheetComponent.prototype.doKeywordSearch = function (searchString) {
        if (searchString.length >= 3) {
            this.searchTerm = searchString;
        }
    };
    TimesheetComponent.prototype.dateconversion = function (splitDate) {
        var syear = splitDate.substring(6);
        var smonth = splitDate.substring(0, 2);
        var sday = splitDate.substring(3, 5);
        return syear.replace(/^\s+|\s+$/g, '') + '-' + smonth.replace(/^\s+|\s+$/g, '') + '-' + sday.replace(/^\s+|\s+$/g, '');
    };
    TimesheetComponent = __decorate([
        core_1.Component({
            selector: 'timesheet',
            templateUrl: './app/timesheets/timesheet/timesheet.component.html'
        }), 
        __metadata('design:paramtypes', [http_client_1.HttpClient, router_1.Router])
    ], TimesheetComponent);
    return TimesheetComponent;
}());
exports.TimesheetComponent = TimesheetComponent;
//# sourceMappingURL=timesheet.component.js.map