import { Component} from '@angular/core';
@Component({
    selector: 'timesheet-list',
    template: '<router-outlet></router-outlet>'
})
export class TimesheetListComponent {
}