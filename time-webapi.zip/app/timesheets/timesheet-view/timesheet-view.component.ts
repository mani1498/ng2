import { Component, ElementRef} from '@angular/core';
import {LazyLoadEvent} from '../../../ng-src/primeng/primeng';
import {HttpClient} from '../../core/http-client';
import {Router} from '@angular/router';
import { PTO} from '../../core/config/config';

declare  var $:any;

@Component({
    selector: 'timesheet',
    templateUrl: './app/timesheets/timesheet-view/timesheet-view.component.html'
})
export class TimesheetViewComponent {


public fromDate:string;
public toDate:string;
public status:string;
public notSubmittedTimesheet;  
public notSubmittedTimesheetValues;
public notSubmittedPTO;
public notSubmittedTimesheetTotalPTO;
public notSubmittedTimesheetvalue;
public notSubmittedTotalPtovalues;
public notSubmittedTotPtovalues; 
public notSubmittedCommentvalues;
public notSubmittedTotalTimevalues; 
public notSubmittedPtovalues;  
public notSubmittedTypename;
public timesheetDetailsSummary;
public notSubmittedTabComment; 
public notSubmittedPtoTimevalues;
private timesheetvaluesExist: boolean = true;
public ptoTypes;
public notSubmittedPtoTotalCalculation;

// For Pto Sections    
public selectedPtoValue:string;  
public ptoTypesConfig = [];    
    
//public notSubmittedTotalTimevaluesArr:[];    
//public notSubmittedTitlenameArr:[];
        
public edited = false;
public notSubmittedTimesheetweek;
public notSubmittedTimesheetweek1;
public notSubmittedTimesheetweekcurrent;
public startDate : string;
public endDate : string;
public notSubmittedprevflag:boolean=false;
public notSubmittednextflag:boolean=false;
public timeSheetBackToTimesheet;
public backToTimesheetJson;   
public backToTimesheet;

public commentFlagDay1 = false;
public commentFlagDay2 = false;
public commentFlagDay3 = false;
public commentFlagDay4 = false;
public commentFlagDay5 = false;
public commentFlagDay6 = false;
public commentFlagDay7 = false;
 
    constructor(private httpClient: HttpClient,private router: Router,private el: ElementRef) {
        this.el = el.nativeElement;
        this.ptoTypesConfig = PTO;
    }
    
    
     reopen(){         
        this.httpClient
           .get('app/mock/timesheet-view/notSubmittedTimesheetEdit.json')
            .then(notSubmittedTimesheetValues => {
                this.timesheetDetailsSummary = notSubmittedTimesheetValues.viewTimesheetSummary.timesheetDetailsSummary;
                this.notSubmittedTypename = notSubmittedTimesheetValues.viewTimesheetSummary.tsTimeSummaries;
                 this.notSubmittedPtovalues = notSubmittedTimesheetValues.viewTimesheetSummary.tsDateSummary;
                 this.notSubmittedTotalTimevalues = notSubmittedTimesheetValues.viewTimesheetSummary.tsTimeTotalSummaries;
            });
    }
    ngOnInit(): void {
       let viewGridPostData = JSON.parse(localStorage.getItem("viewGridPostData")); 
        console.log(viewGridPostData);      
        this.httpClient
           .post('http://localhost:8081/atlis/timesheet/getTimesheetData/',viewGridPostData)
            .then(notSubmittedTimesheetValues => {
                this.timesheetDetailsSummary = notSubmittedTimesheetValues.viewTimesheetSummary.timesheetDetailsSummary;
                this.notSubmittedTypename = notSubmittedTimesheetValues.viewTimesheetSummary.tsTimeSummaries;
                this.notSubmittedPtovalues = notSubmittedTimesheetValues.viewTimesheetSummary.tsDateSummary;
                this.notSubmittedTotalTimevalues = notSubmittedTimesheetValues.viewTimesheetSummary.tsTimeTotalSummaries;
                this.notSubmittedPtoTimevalues = notSubmittedTimesheetValues.viewTimesheetSummary.ptoSummaries;
                this.notSubmittedPtoTotalCalculation = notSubmittedTimesheetValues.viewTimesheetSummary.tsTimeTotalSummaries;
                this.getDateRange(viewGridPostData);
                
            });        
    }        
    
   	
  /*****   Back to timesheet Changes By merline ***********/
	submit() {  
	    this.httpClient.get('app/mock/timesheet-view/backToTimesheet.json?=rnd')
		    .then(backToTimesheetJson => {
	           this.backToTimesheetJson = backToTimesheetJson;
	           if(this.backToTimesheetJson){
			    this.httpClient
			        .post('http://localhost:8081/atlis/timesheet/saveTimesheet/',this.backToTimesheetJson)
			        .then(backToTimesheet => {
			           this.backToTimesheet = backToTimesheet;
			           
			           this.router.navigate(['/timetrack/timesheet']);
			       });
		    	}
	    });
	}
 /*****   Back to timesheet Ends By merline ***********/



 getDateRange(viewGridPostDatas){
     let params_1 = {"employeeId": viewGridPostDatas.employeeId};
        this.httpClient
           .post('http://localhost:8081/atlis/timesheet/getDateRange/',params_1)
            .then(notSubmittedTimesheetweek => {
                this.notSubmittedTimesheetweek = notSubmittedTimesheetweek;
                //console.log('this.notSubmittedTimesheetweek--------->',this.notSubmittedTimesheetweek);
            this.notSubmittedTimesheetweek1 = [];
               
               	for (var i = 0; i < this.notSubmittedTimesheetweek.timesheetPeriodListVO.length; i++) {
               	
    				var num = this.notSubmittedTimesheetweek.timesheetPeriodListVO[i];
   					 
    				if(i==0){
     					this.notSubmittedTimesheetweek1.push({
			                "prevflag": false,
			                "timeperiod": num.timesheetPeriod,
			                "timesheetId": num.timesheetId,
			                "timesheetDate": num.timesheetDate,
			                "nextflag": true
			            });
    				}
    				else if(i == (this.notSubmittedTimesheetweek.length)-1){
     					this.notSubmittedTimesheetweek1.push({
                			"prevflag": true,
			                "timeperiod": num.timesheetPeriod,
			                 "timesheetId": num.timesheetId,
			                "timesheetDate": num.timesheetDate,
			                "nextflag": false
			            });
    				}
  					else{
  						this.notSubmittedTimesheetweek1.push({
			                "prevflag": true,
			                "timeperiod": num.timesheetPeriod,
			                "timesheetId": num.timesheetId,
			                "timesheetDate": num.timesheetDate,
			                "nextflag": true
			            });
  					}
				}
 				for (var wk1 = 0; wk1 < this.notSubmittedTimesheetweek1.length; wk1++) {
     				if(this.notSubmittedTimesheetweek1[wk1].timeperiod)
            		{
           				let splitDate = this.notSubmittedTimesheetweek1[wk1].timeperiod.split(/-/);
            			this.startDate = splitDate[0].replace(/^\s+|\s+$/g, '');
    					this.endDate = splitDate[1].replace(/^\s+|\s+$/g, '');  
    					
    					//console.log('Start Date : '+this.startDate,' EndDate : '+this.endDate);
    					
    					//console.log('date :::::::::::::::',this.timesheetDetailsSummary.fdate);
    			 		let fdates= this.timesheetDetailsSummary.fdate.substr(3);
    			 		let fdates1 = fdates.replace(",", "");
    			 		let fdates2 = fdates1.replace("on", "");
    			 		let fdates3= fdates2.trim();
    			 		
    			 		let ddates= this.timesheetDetailsSummary.tdate.substr(3);
    			 		let ddates1 = ddates.replace(",", "");
    			 		let ddates2 = ddates1.replace("on", "");
    			 		let ddates3= ddates2.trim();
    			 		
    			 		//console.log('ddates3',ddates3);
    			 		//console.log('endDate',this.endDate);
    			 		
			 			if(fdates3 == this.startDate && ddates3 == this.endDate){
    			 		
    			 			this.notSubmittedTimesheetweekcurrent = this.notSubmittedTimesheetweek1[wk1].timeperiod;
    			 		
    					 this.notSubmittedprevflag = this.notSubmittedTimesheetweek1[wk1].prevflag;
    					 this.notSubmittednextflag = this.notSubmittedTimesheetweek1[wk1].nextflag;
    					 
    				 }
            	} 
			}                  
                
        });            
    } 

previousWeek(weekObject,currentWeekValue)
   	{
 		var dec = -1;
 		for (let weekValue of weekObject)
 		{
	 		if(weekValue.timeperiod == currentWeekValue)
	 		{	
	 			let splitDate = (weekObject[dec].timesheetDate.split(/-/));
    			this.startDate = splitDate[0]+'-'+splitDate[1]+'-'+splitDate[2];
				this.endDate = splitDate[3]+'-'+splitDate[4]+'-'+splitDate[5];  
	 			let viewGridPostData = JSON.parse(localStorage.getItem("viewGridPostData")); 
	 			let params={"reqFrom":"web", "employeeId":viewGridPostData.employeeId, "timesheetId":viewGridPostData.timesheetId, "startDate":this.startDate, "endDate":this.endDate};
	 			this.httpClient
	           	.post('http://localhost:8081/atlis/timesheet/getTimesheetData/',params)
	            .then(notSubmittedTimesheetValues => {
	                 this.timesheetDetailsSummary = notSubmittedTimesheetValues.viewTimesheetSummary.timesheetDetailsSummary;
	                this.notSubmittedTypename = notSubmittedTimesheetValues.viewTimesheetSummary.tsTimeSummaries;
	                 this.notSubmittedPtovalues = notSubmittedTimesheetValues.viewTimesheetSummary.tsDateSummary;
	                 this.notSubmittedTotalTimevalues = notSubmittedTimesheetValues.viewTimesheetSummary.tsTimeTotalSummaries;
	                 this.notSubmittedPtoTimevalues = notSubmittedTimesheetValues.viewTimesheetSummary.ptoSummaries;
	            });
	 			this.notSubmittedTimesheetweekcurrent = weekObject[dec].timeperiod;
	 			
	 			if(dec == 0)
	 			{
	 				this.notSubmittedprevflag = false;
	 				this.notSubmittednextflag = true;
	 			}
	 			else
	 			{
	 				this.notSubmittedprevflag = true;
	 				this.notSubmittednextflag = true;
	 			}
	 		}
	 		dec++;
		}
 	}
 	
 	nextWeek(weekObject,currentWeekValue)
 	{
 		var inc =0;
 		var sum =1;
 		for (let weekValue of weekObject) 
 		{
	 		inc++;
	 		sum++;
	 		if(weekValue.timeperiod == currentWeekValue)
	 		{
	 		
 				let splitDate = (weekObject[inc].timesheetDate.split(/-/));
            			this.startDate = splitDate[0]+'-'+splitDate[1]+'-'+splitDate[2];
    					this.endDate = splitDate[3]+'-'+splitDate[4]+'-'+splitDate[5];  
    			 let viewGridPostData = JSON.parse(localStorage.getItem("viewGridPostData")); 
	 			let params={"reqFrom":"web", "employeeId":viewGridPostData.employeeId, "timesheetId":viewGridPostData.timesheetId, "startDate":this.startDate, "endDate":this.endDate};
	 			this.httpClient
	           	.post('http://localhost:8081/atlis/timesheet/getTimesheetData/',viewGridPostData)
	            .then(notSubmittedTimesheetValues => {
	                 this.timesheetDetailsSummary = notSubmittedTimesheetValues.viewTimesheetSummary.timesheetDetailsSummary;
	                this.notSubmittedTypename = notSubmittedTimesheetValues.viewTimesheetSummary.tsTimeSummaries;
	                 this.notSubmittedPtovalues = notSubmittedTimesheetValues.viewTimesheetSummary.tsDateSummary;
	                 this.notSubmittedTotalTimevalues = notSubmittedTimesheetValues.viewTimesheetSummary.tsTimeTotalSummaries;
	                 this.notSubmittedPtoTimevalues = notSubmittedTimesheetValues.viewTimesheetSummary.ptoSummaries;
        		});  
	 		
	 			this.notSubmittedTimesheetweekcurrent = weekObject[inc].timeperiod;
	 			if(sum == weekObject.length)
	 			{
	 				this.notSubmittednextflag = false;
	 				this.notSubmittedprevflag = true;
	 			}
	 			else
	 			{
	 				this.notSubmittedprevflag = true;
	 				this.notSubmittednextflag = true;
	 			}
	 		}
		}
 	
 	}  
    
   showCommentFun(timeValue,dayFlag){
   
   		if(dayFlag == 'day1Flag'){
   			this.commentFlagDay1 = true;
   		}
   		else if(dayFlag == 'day2Flag'){
   			this.commentFlagDay2 = true;
   		}
   		else if(dayFlag == 'day3Flag'){
   			this.commentFlagDay3 = true;
   		}
   		else if(dayFlag == 'day4Flag'){
   			this.commentFlagDay4 = true;
   		}
   		else if(dayFlag == 'day5Flag'){
   			this.commentFlagDay5 = true;
   		}
   		else if(dayFlag == 'day6Flag'){
   			this.commentFlagDay6 = true;
   		}
   		else if(dayFlag == 'day7Flag'){
   			this.commentFlagDay7 = true;
   		}
   }
   
   timeSheetCalculation(event:any,timeValue,maxHours:number,day:string):void{
   		
   		this.timesheetvaluesExist = true;
   		if(maxHours == 24){
   			var isValid = /^([0-1]?[0-9]|2[0-3]).([0-5][0-9])(.[0-5][0-9])?$/.test(event.target.value);
   		}
   		else if(maxHours == 8){
   			var isValid = /^([0]?[0-7]|0[0-7]).([0-5][0-9])(.[0-5][0-9])?$/.test(event.target.value);
		}
         if(isNaN(event.target.value) || (!isValid && event.target.value.length>4)){
            event.target.value = '0.00';
           if(day == 'day1'){
           		timeValue.day1 = '0.00';
           }
           else if(day == 'day2'){
           		timeValue.day2 = '0.00';
           }
           else if(day == 'day3'){
           		timeValue.day3 = '0.00';
           }
           else if(day == 'day4'){
           		timeValue.day4 = '0.00';
           }
           else if(day == 'day5'){
           		timeValue.day5 = '0.00';
           }
           else if(day == 'day6'){
           		timeValue.day6 = '0.00';
           }
           else if(day == 'day7'){
           		timeValue.day7 = '0.00';
           }
        }
        
         timeValue.total = (
	        parseFloat(timeValue.day1)+parseFloat(timeValue.day2)+
	        parseFloat(timeValue.day3)+parseFloat(timeValue.day4)+
	        parseFloat(timeValue.day5)+parseFloat(timeValue.day6)+
	        parseFloat(timeValue.day7)
	        ).toFixed(2);
   	}
    
    /*****   PTO Changes By Mani ***********/
    
    selectPto(selectedPto:string,rootObj:number,ptoCount:number){
        console.log('df',this.ptoTypesConfig);
        if(this.ptoTypesConfig.length > 0){
            $('.popover').hide();
            this.notSubmittedPtoTimevalues[rootObj].timeOffType=selectedPto;
            this.ptoTypesConfig.splice(ptoCount,1);
            console.log('tttSel',this.selectedPtoValue);
           /* if(this.selectedPtoValue != selectedPto && this.selectedPtoValue != ''){
                console.log('selectedPtoValue',this.selectedPtoValue);
                this.ptoTypesConfig.push({"reason":this.selectedPtoValue});
            }*/
        }
    }
    
    enablePopover(selectedPtoValue:string){
        console.log('ttt333',selectedPtoValue);
        if(selectedPtoValue != 'Select'){
            console.log('ttt',selectedPtoValue);
            this.selectedPtoValue=selectedPtoValue;
        }
        $('.popover').show();
    }
    
    addPto(){
        console.log(this.notSubmittedPtoTimevalues);
        if(this.ptoTypesConfig.length > 0 && this.notSubmittedPtoTimevalues.length < 5){
        this.notSubmittedPtoTimevalues.push({
                "timeOffType": 'Select',
                "day1": "0.00",
                "day2": "0.00",
                "day3": "0.00",
                "day4": "0.00",
                "day5": "0.00",
                "day6": "0.00",
                "day7": "0.00",
                "total":"0.00",
                "type":"new"
            });
        }
    }
    deletepto(ptotype:string,ptoid:number){
        console.log('ptotype',ptotype);
        this.notSubmittedPtoTimevalues.splice(ptoid,1);
        //console.log('removedPtoTypes',this.removedPtoTypes);
        this.ptoTypesConfig.push({"reason":ptotype});
    }
}
