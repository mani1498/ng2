"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var http_client_1 = require('../../core/http-client');
var router_1 = require('@angular/router');
var config_1 = require('../../core/config/config');
var TimesheetViewComponent = (function () {
    function TimesheetViewComponent(httpClient, router, el) {
        this.httpClient = httpClient;
        this.router = router;
        this.el = el;
        this.timesheetvaluesExist = true;
        this.ptoTypesConfig = [];
        //public notSubmittedTotalTimevaluesArr:[];    
        //public notSubmittedTitlenameArr:[];
        this.edited = false;
        this.notSubmittedprevflag = false;
        this.notSubmittednextflag = false;
        this.commentFlagDay1 = false;
        this.commentFlagDay2 = false;
        this.commentFlagDay3 = false;
        this.commentFlagDay4 = false;
        this.commentFlagDay5 = false;
        this.commentFlagDay6 = false;
        this.commentFlagDay7 = false;
        this.el = el.nativeElement;
        this.ptoTypesConfig = config_1.PTO;
    }
    TimesheetViewComponent.prototype.reopen = function () {
        var _this = this;
        this.httpClient
            .get('app/mock/timesheet-view/notSubmittedTimesheetEdit.json')
            .then(function (notSubmittedTimesheetValues) {
            _this.timesheetDetailsSummary = notSubmittedTimesheetValues.viewTimesheetSummary.timesheetDetailsSummary;
            _this.notSubmittedTypename = notSubmittedTimesheetValues.viewTimesheetSummary.tsTimeSummaries;
            _this.notSubmittedPtovalues = notSubmittedTimesheetValues.viewTimesheetSummary.tsDateSummary;
            _this.notSubmittedTotalTimevalues = notSubmittedTimesheetValues.viewTimesheetSummary.tsTimeTotalSummaries;
        });
    };
    TimesheetViewComponent.prototype.ngOnInit = function () {
        var _this = this;
        var viewGridPostData = JSON.parse(localStorage.getItem("viewGridPostData"));
        console.log(viewGridPostData);
        this.httpClient
            .post('http://localhost:8081/atlis/timesheet/getTimesheetData/', viewGridPostData)
            .then(function (notSubmittedTimesheetValues) {
            _this.timesheetDetailsSummary = notSubmittedTimesheetValues.viewTimesheetSummary.timesheetDetailsSummary;
            _this.notSubmittedTypename = notSubmittedTimesheetValues.viewTimesheetSummary.tsTimeSummaries;
            _this.notSubmittedPtovalues = notSubmittedTimesheetValues.viewTimesheetSummary.tsDateSummary;
            _this.notSubmittedTotalTimevalues = notSubmittedTimesheetValues.viewTimesheetSummary.tsTimeTotalSummaries;
            _this.notSubmittedPtoTimevalues = notSubmittedTimesheetValues.viewTimesheetSummary.ptoSummaries;
            _this.notSubmittedPtoTotalCalculation = notSubmittedTimesheetValues.viewTimesheetSummary.tsTimeTotalSummaries;
            _this.getDateRange(viewGridPostData);
        });
    };
    /*****   Back to timesheet Changes By merline ***********/
    TimesheetViewComponent.prototype.submit = function () {
        var _this = this;
        this.httpClient.get('app/mock/timesheet-view/backToTimesheet.json?=rnd')
            .then(function (backToTimesheetJson) {
            _this.backToTimesheetJson = backToTimesheetJson;
            if (_this.backToTimesheetJson) {
                _this.httpClient
                    .post('http://localhost:8081/atlis/timesheet/saveTimesheet/', _this.backToTimesheetJson)
                    .then(function (backToTimesheet) {
                    _this.backToTimesheet = backToTimesheet;
                    _this.router.navigate(['/timetrack/timesheet']);
                });
            }
        });
    };
    /*****   Back to timesheet Ends By merline ***********/
    TimesheetViewComponent.prototype.getDateRange = function (viewGridPostDatas) {
        var _this = this;
        var params_1 = { "employeeId": viewGridPostDatas.employeeId };
        this.httpClient
            .post('http://localhost:8081/atlis/timesheet/getDateRange/', params_1)
            .then(function (notSubmittedTimesheetweek) {
            _this.notSubmittedTimesheetweek = notSubmittedTimesheetweek;
            //console.log('this.notSubmittedTimesheetweek--------->',this.notSubmittedTimesheetweek);
            _this.notSubmittedTimesheetweek1 = [];
            for (var i = 0; i < _this.notSubmittedTimesheetweek.timesheetPeriodListVO.length; i++) {
                var num = _this.notSubmittedTimesheetweek.timesheetPeriodListVO[i];
                if (i == 0) {
                    _this.notSubmittedTimesheetweek1.push({
                        "prevflag": false,
                        "timeperiod": num.timesheetPeriod,
                        "timesheetId": num.timesheetId,
                        "timesheetDate": num.timesheetDate,
                        "nextflag": true
                    });
                }
                else if (i == (_this.notSubmittedTimesheetweek.length) - 1) {
                    _this.notSubmittedTimesheetweek1.push({
                        "prevflag": true,
                        "timeperiod": num.timesheetPeriod,
                        "timesheetId": num.timesheetId,
                        "timesheetDate": num.timesheetDate,
                        "nextflag": false
                    });
                }
                else {
                    _this.notSubmittedTimesheetweek1.push({
                        "prevflag": true,
                        "timeperiod": num.timesheetPeriod,
                        "timesheetId": num.timesheetId,
                        "timesheetDate": num.timesheetDate,
                        "nextflag": true
                    });
                }
            }
            for (var wk1 = 0; wk1 < _this.notSubmittedTimesheetweek1.length; wk1++) {
                if (_this.notSubmittedTimesheetweek1[wk1].timeperiod) {
                    var splitDate = _this.notSubmittedTimesheetweek1[wk1].timeperiod.split(/-/);
                    _this.startDate = splitDate[0].replace(/^\s+|\s+$/g, '');
                    _this.endDate = splitDate[1].replace(/^\s+|\s+$/g, '');
                    //console.log('Start Date : '+this.startDate,' EndDate : '+this.endDate);
                    //console.log('date :::::::::::::::',this.timesheetDetailsSummary.fdate);
                    var fdates = _this.timesheetDetailsSummary.fdate.substr(3);
                    var fdates1 = fdates.replace(",", "");
                    var fdates2 = fdates1.replace("on", "");
                    var fdates3 = fdates2.trim();
                    var ddates = _this.timesheetDetailsSummary.tdate.substr(3);
                    var ddates1 = ddates.replace(",", "");
                    var ddates2 = ddates1.replace("on", "");
                    var ddates3 = ddates2.trim();
                    //console.log('ddates3',ddates3);
                    //console.log('endDate',this.endDate);
                    if (fdates3 == _this.startDate && ddates3 == _this.endDate) {
                        _this.notSubmittedTimesheetweekcurrent = _this.notSubmittedTimesheetweek1[wk1].timeperiod;
                        _this.notSubmittedprevflag = _this.notSubmittedTimesheetweek1[wk1].prevflag;
                        _this.notSubmittednextflag = _this.notSubmittedTimesheetweek1[wk1].nextflag;
                    }
                }
            }
        });
    };
    TimesheetViewComponent.prototype.previousWeek = function (weekObject, currentWeekValue) {
        var _this = this;
        var dec = -1;
        for (var _i = 0, weekObject_1 = weekObject; _i < weekObject_1.length; _i++) {
            var weekValue = weekObject_1[_i];
            if (weekValue.timeperiod == currentWeekValue) {
                var splitDate = (weekObject[dec].timesheetDate.split(/-/));
                this.startDate = splitDate[0] + '-' + splitDate[1] + '-' + splitDate[2];
                this.endDate = splitDate[3] + '-' + splitDate[4] + '-' + splitDate[5];
                var viewGridPostData = JSON.parse(localStorage.getItem("viewGridPostData"));
                var params = { "reqFrom": "web", "employeeId": viewGridPostData.employeeId, "timesheetId": viewGridPostData.timesheetId, "startDate": this.startDate, "endDate": this.endDate };
                this.httpClient
                    .post('http://localhost:8081/atlis/timesheet/getTimesheetData/', params)
                    .then(function (notSubmittedTimesheetValues) {
                    _this.timesheetDetailsSummary = notSubmittedTimesheetValues.viewTimesheetSummary.timesheetDetailsSummary;
                    _this.notSubmittedTypename = notSubmittedTimesheetValues.viewTimesheetSummary.tsTimeSummaries;
                    _this.notSubmittedPtovalues = notSubmittedTimesheetValues.viewTimesheetSummary.tsDateSummary;
                    _this.notSubmittedTotalTimevalues = notSubmittedTimesheetValues.viewTimesheetSummary.tsTimeTotalSummaries;
                    _this.notSubmittedPtoTimevalues = notSubmittedTimesheetValues.viewTimesheetSummary.ptoSummaries;
                });
                this.notSubmittedTimesheetweekcurrent = weekObject[dec].timeperiod;
                if (dec == 0) {
                    this.notSubmittedprevflag = false;
                    this.notSubmittednextflag = true;
                }
                else {
                    this.notSubmittedprevflag = true;
                    this.notSubmittednextflag = true;
                }
            }
            dec++;
        }
    };
    TimesheetViewComponent.prototype.nextWeek = function (weekObject, currentWeekValue) {
        var _this = this;
        var inc = 0;
        var sum = 1;
        for (var _i = 0, weekObject_2 = weekObject; _i < weekObject_2.length; _i++) {
            var weekValue = weekObject_2[_i];
            inc++;
            sum++;
            if (weekValue.timeperiod == currentWeekValue) {
                var splitDate = (weekObject[inc].timesheetDate.split(/-/));
                this.startDate = splitDate[0] + '-' + splitDate[1] + '-' + splitDate[2];
                this.endDate = splitDate[3] + '-' + splitDate[4] + '-' + splitDate[5];
                var viewGridPostData = JSON.parse(localStorage.getItem("viewGridPostData"));
                var params = { "reqFrom": "web", "employeeId": viewGridPostData.employeeId, "timesheetId": viewGridPostData.timesheetId, "startDate": this.startDate, "endDate": this.endDate };
                this.httpClient
                    .post('http://localhost:8081/atlis/timesheet/getTimesheetData/', viewGridPostData)
                    .then(function (notSubmittedTimesheetValues) {
                    _this.timesheetDetailsSummary = notSubmittedTimesheetValues.viewTimesheetSummary.timesheetDetailsSummary;
                    _this.notSubmittedTypename = notSubmittedTimesheetValues.viewTimesheetSummary.tsTimeSummaries;
                    _this.notSubmittedPtovalues = notSubmittedTimesheetValues.viewTimesheetSummary.tsDateSummary;
                    _this.notSubmittedTotalTimevalues = notSubmittedTimesheetValues.viewTimesheetSummary.tsTimeTotalSummaries;
                    _this.notSubmittedPtoTimevalues = notSubmittedTimesheetValues.viewTimesheetSummary.ptoSummaries;
                });
                this.notSubmittedTimesheetweekcurrent = weekObject[inc].timeperiod;
                if (sum == weekObject.length) {
                    this.notSubmittednextflag = false;
                    this.notSubmittedprevflag = true;
                }
                else {
                    this.notSubmittedprevflag = true;
                    this.notSubmittednextflag = true;
                }
            }
        }
    };
    TimesheetViewComponent.prototype.showCommentFun = function (timeValue, dayFlag) {
        if (dayFlag == 'day1Flag') {
            this.commentFlagDay1 = true;
        }
        else if (dayFlag == 'day2Flag') {
            this.commentFlagDay2 = true;
        }
        else if (dayFlag == 'day3Flag') {
            this.commentFlagDay3 = true;
        }
        else if (dayFlag == 'day4Flag') {
            this.commentFlagDay4 = true;
        }
        else if (dayFlag == 'day5Flag') {
            this.commentFlagDay5 = true;
        }
        else if (dayFlag == 'day6Flag') {
            this.commentFlagDay6 = true;
        }
        else if (dayFlag == 'day7Flag') {
            this.commentFlagDay7 = true;
        }
    };
    TimesheetViewComponent.prototype.timeSheetCalculation = function (event, timeValue, maxHours, day) {
        this.timesheetvaluesExist = true;
        if (maxHours == 24) {
            var isValid = /^([0-1]?[0-9]|2[0-3]).([0-5][0-9])(.[0-5][0-9])?$/.test(event.target.value);
        }
        else if (maxHours == 8) {
            var isValid = /^([0]?[0-7]|0[0-7]).([0-5][0-9])(.[0-5][0-9])?$/.test(event.target.value);
        }
        if (isNaN(event.target.value) || (!isValid && event.target.value.length > 4)) {
            event.target.value = '0.00';
            if (day == 'day1') {
                timeValue.day1 = '0.00';
            }
            else if (day == 'day2') {
                timeValue.day2 = '0.00';
            }
            else if (day == 'day3') {
                timeValue.day3 = '0.00';
            }
            else if (day == 'day4') {
                timeValue.day4 = '0.00';
            }
            else if (day == 'day5') {
                timeValue.day5 = '0.00';
            }
            else if (day == 'day6') {
                timeValue.day6 = '0.00';
            }
            else if (day == 'day7') {
                timeValue.day7 = '0.00';
            }
        }
        timeValue.total = (parseFloat(timeValue.day1) + parseFloat(timeValue.day2) +
            parseFloat(timeValue.day3) + parseFloat(timeValue.day4) +
            parseFloat(timeValue.day5) + parseFloat(timeValue.day6) +
            parseFloat(timeValue.day7)).toFixed(2);
    };
    /*****   PTO Changes By Mani ***********/
    TimesheetViewComponent.prototype.selectPto = function (selectedPto, rootObj, ptoCount) {
        console.log('df', this.ptoTypesConfig);
        if (this.ptoTypesConfig.length > 0) {
            $('.popover').hide();
            this.notSubmittedPtoTimevalues[rootObj].timeOffType = selectedPto;
            this.ptoTypesConfig.splice(ptoCount, 1);
            console.log('tttSel', this.selectedPtoValue);
        }
    };
    TimesheetViewComponent.prototype.enablePopover = function (selectedPtoValue) {
        console.log('ttt333', selectedPtoValue);
        if (selectedPtoValue != 'Select') {
            console.log('ttt', selectedPtoValue);
            this.selectedPtoValue = selectedPtoValue;
        }
        $('.popover').show();
    };
    TimesheetViewComponent.prototype.addPto = function () {
        console.log(this.notSubmittedPtoTimevalues);
        if (this.ptoTypesConfig.length > 0 && this.notSubmittedPtoTimevalues.length < 5) {
            this.notSubmittedPtoTimevalues.push({
                "timeOffType": 'Select',
                "day1": "0.00",
                "day2": "0.00",
                "day3": "0.00",
                "day4": "0.00",
                "day5": "0.00",
                "day6": "0.00",
                "day7": "0.00",
                "total": "0.00",
                "type": "new"
            });
        }
    };
    TimesheetViewComponent.prototype.deletepto = function (ptotype, ptoid) {
        console.log('ptotype', ptotype);
        this.notSubmittedPtoTimevalues.splice(ptoid, 1);
        //console.log('removedPtoTypes',this.removedPtoTypes);
        this.ptoTypesConfig.push({ "reason": ptotype });
    };
    TimesheetViewComponent = __decorate([
        core_1.Component({
            selector: 'timesheet',
            templateUrl: './app/timesheets/timesheet-view/timesheet-view.component.html'
        }), 
        __metadata('design:paramtypes', [http_client_1.HttpClient, router_1.Router, core_1.ElementRef])
    ], TimesheetViewComponent);
    return TimesheetViewComponent;
}());
exports.TimesheetViewComponent = TimesheetViewComponent;
//# sourceMappingURL=timesheet-view.component.js.map