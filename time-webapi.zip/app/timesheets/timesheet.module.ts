import { NgModule }      from '@angular/core';
import { CommonModule }       from '@angular/common';
import {ModalModule} from "ng2-modal";
import {DataTableModule,SharedModule} from 'primeng/primeng';
import { TimesheetListComponent }  from './timesheet-list/timesheet-list.component';
import { TimesheetViewComponent }  from './timesheet-view/timesheet-view.component';
import { TimesheetComponent }  from './timesheet/timesheet.component';
import { LayoutComponent } from '../layout/layout.component';
import { timesheetRouting }  from './timesheet.routing';
import {DateRangePickerDirective} from '../shared/directives/daterangepicker';
import { PopoverModule }  from '../shared/popover/index';
import { FormsModule }   from '@angular/forms';

@NgModule({
    imports:      [ CommonModule, ModalModule, timesheetRouting,
        DataTableModule,
        SharedModule ,PopoverModule,FormsModule ],
    declarations: [ TimesheetComponent,TimesheetListComponent,LayoutComponent,TimesheetViewComponent,DateRangePickerDirective ]
})
export class TimesheetModule { }