import { Directive, ElementRef, Input, NgZone, HostListener, Output, EventEmitter } from '@angular/core';
declare var $: any;
declare var moment: any;
var that;
@Directive( {
    selector: '[dateRangePicker]',
})
export class DateRangePickerDirective {
    @Input( 'dateRangePicker' ) setDate: string;
    @Output() onSelectDone = new EventEmitter();
    public el: HTMLElement;
    public start: string = moment();
    public end: string = moment();

    constructor( el: ElementRef, public zone: NgZone ) {
        this.el = el.nativeElement;
        that = this;
    }
    ngOnInit() {
        const component = this;
        this.showDatePicker();
    }
    showDatePicker() {
        $( this.el ).daterangepicker( {
            locale: {
                format: 'MM/DD/YYYY'
            },
            startDate: this.start,
            endDate: this.end,
        },
            function onSelectDone( start, end, label ) {
                that.onSelectDone.emit( {
                    start: start.format( 'MM/DD/YYYY' ),
                    end: end.format( 'MM/DD/YYYY' )
                });
            }
        );
    }
}