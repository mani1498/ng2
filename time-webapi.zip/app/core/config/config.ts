import { Component} from '@angular/core';
import { ConfigEnvironment, PTOConfig } from './config-interface';

export const ENVIRONMENTS: ConfigEnvironment = {
  mock: true,
  service:  false,
  serviceUrl:'http://localhost:8089/timetrack/'
};

export const PTO: PTOConfig[] = [
  {reason:"Vacation"}, 
  {reason: "Sick"},
  {reason: "Jury Duty"},
  {reason:"Bereavement"}
];

