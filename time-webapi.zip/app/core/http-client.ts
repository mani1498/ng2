import { Injectable }    from '@angular/core';
import { Headers, RequestOptions, Http } from '@angular/http';
import 'rxjs/add/operator/toPromise';
import {Observable} from 'rxjs/Observable';
import { ENVIRONMENTS} from './config/config';

@Injectable()

export class HttpClient {
    private urlContext:string='';
    private token:string=window.localStorage.getItem('access_token');
    private combined:{};
    private mock:boolean=ENVIRONMENTS.mock;
    constructor(private http: Http) { }

    //save predefined service Url Context
    setUrlContext(urlContext) {
        console.log('mock',this.mock);
        this.urlContext = this.mock ==  true ? '' : urlContext;
    }
    //Get predefined service Url Context
    getUrlContext() {
        return this.urlContext;
    }

    get(url) {
        return this.http.get(this.urlContext+url)
            .toPromise()
            .then(response => response.json())
            .catch(this.handleError);
    }
    post(url,params) {
        let headers = new Headers(
            {
                "Content-Type": "application/json",
                "Authorization": "Basic " + this.token
            }
        );
        let options = new RequestOptions({ headers: headers });
        
        return this.http.post(this.urlContext+url, params, options)
            .toPromise()
            .then(response => response.json())
            .catch(this.handleError);
    }
    private handleError(error: any): Promise<any> {
        console.error('An error occurred', error); // for demo purposes only
        return Promise.reject(error.message || error);
    }
    
    
}
