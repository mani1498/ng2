"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var http_1 = require('@angular/http');
require('rxjs/add/operator/toPromise');
var config_1 = require('./config/config');
var HttpClient = (function () {
    function HttpClient(http) {
        this.http = http;
        this.urlContext = '';
        this.token = window.localStorage.getItem('access_token');
        this.mock = config_1.ENVIRONMENTS.mock;
    }
    //save predefined service Url Context
    HttpClient.prototype.setUrlContext = function (urlContext) {
        console.log('mock', this.mock);
        this.urlContext = this.mock == true ? '' : urlContext;
    };
    //Get predefined service Url Context
    HttpClient.prototype.getUrlContext = function () {
        return this.urlContext;
    };
    HttpClient.prototype.get = function (url) {
        return this.http.get(this.urlContext + url)
            .toPromise()
            .then(function (response) { return response.json(); })
            .catch(this.handleError);
    };
    HttpClient.prototype.post = function (url, params) {
        var headers = new http_1.Headers({
            "Content-Type": "application/json",
            "Authorization": "Basic " + this.token
        });
        var options = new http_1.RequestOptions({ headers: headers });
        return this.http.post(this.urlContext + url, params, options)
            .toPromise()
            .then(function (response) { return response.json(); })
            .catch(this.handleError);
    };
    HttpClient.prototype.handleError = function (error) {
        console.error('An error occurred', error); // for demo purposes only
        return Promise.reject(error.message || error);
    };
    HttpClient = __decorate([
        core_1.Injectable(), 
        __metadata('design:paramtypes', [http_1.Http])
    ], HttpClient);
    return HttpClient;
}());
exports.HttpClient = HttpClient;
//# sourceMappingURL=http-client.js.map