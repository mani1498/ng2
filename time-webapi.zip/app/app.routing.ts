import { Routes, RouterModule } from '@angular/router';
import { LoginComponent }      from './login/login.component';
import { AuthGuard } from './core/auth-guard.service';

const appRoutes: Routes = [
    {
        path: '',
        redirectTo: 'timesheet/',
        pathMatch: 'full'
    },
    {
        path: 'timesheet/',
        component: LoginComponent,
    },
    {
        path: 'timetrack',
        canActivate: [AuthGuard],
        loadChildren: 'app/timesheets/timesheet.module#TimesheetModule'
    },
    {
        path: 'timetrack',
        canActivate: [AuthGuard],
        loadChildren: 'app/timeoffs/timeoff.module#TimeoffModule'
    }
];
export const routing = RouterModule.forRoot(appRoutes);

