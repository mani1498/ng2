$(document).ready(function() {
	
	$('[data-toggle="tooltip"]').tooltip();
	
	$(document).on("click", "#ems_headernav", function() {
		$("body").toggleClass("sidebar-collapse");
	});

	$(document).on('click', '.sidebar-menu .clickable_menu', function() {
		if ($(window).width() <= 767) {
			$("body").toggleClass("sidebar-collapse");
		}
	});

	// Back to top window scroll
	$(document).on('click', '.back-to-top', function() {
		$('html,body').animate({
			scrollTop : 0
		}, 'slow');
	});
	// For Grid sortable active/Inactive class 
	$(document).on('click', '.grid-sorting-list li', function() {
			if(!$(this).hasClass('active')) {
				$(this).parent().find('li').removeClass('active');
				$(this).addClass('active');
			}
	});
	// Check mobile devices
	var checkMobileDevice = function() { 
		if ($(window).innerWidth() < 992) {
			$('body').addClass('mobile-device');
		} else {
			if ($('body').hasClass('mobile-device')) {
				$('body').removeClass('mobile-device');
			}
			$("body").removeClass("sidebar-collapse");
		}
	};
	// For On ready state
	checkMobileDevice();
	
	// Menu Resize event for page content
	$(window).bind('resize', function() {
		// For Page layout
		checkMobileDevice();
	});
	
	
});