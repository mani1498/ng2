"use strict";
var router_1 = require('@angular/router');
var login_component_1 = require('./login/login.component');
var auth_guard_service_1 = require('./core/auth-guard.service');
var appRoutes = [
    {
        path: '',
        redirectTo: 'timesheet/',
        pathMatch: 'full'
    },
    {
        path: 'timesheet/',
        component: login_component_1.LoginComponent,
    },
    {
        path: 'timetrack',
        canActivate: [auth_guard_service_1.AuthGuard],
        loadChildren: 'app/timesheets/timesheet.module#TimesheetModule'
    },
    {
        path: 'timetrack',
        canActivate: [auth_guard_service_1.AuthGuard],
        loadChildren: 'app/timeoffs/timeoff.module#TimeoffModule'
    }
];
exports.routing = router_1.RouterModule.forRoot(appRoutes);
//# sourceMappingURL=app.routing.js.map