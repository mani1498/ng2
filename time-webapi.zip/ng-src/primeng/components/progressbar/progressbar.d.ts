export declare class ProgressBar {
    value: any;
    showValue: boolean;
}
export declare class ProgressBarModule {
}
