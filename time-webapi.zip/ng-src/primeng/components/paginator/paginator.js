"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var common_1 = require('@angular/common');
var Paginator = (function () {
    function Paginator() {
        this.rows = 0;
        this.pageLinkSize = 5;
        this.onPageChange = new core_1.EventEmitter();
        this._totalRecords = 0;
        this._first = 0;
    }
    Object.defineProperty(Paginator.prototype, "totalRecords", {
        get: function () {
            return this._totalRecords;
        },
        set: function (val) {
            this._totalRecords = val;
            this.updatePageLinks();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Paginator.prototype, "first", {
        get: function () {
            return this._first;
        },
        set: function (val) {
            this._first = val;
            this.updatePageLinks();
        },
        enumerable: true,
        configurable: true
    });
    Paginator.prototype.isFirstPage = function () {
        return this.getPage() === 0;
    };
    Paginator.prototype.isLastPage = function () {
        return this.getPage() === this.getPageCount() - 1;
    };
    Paginator.prototype.getPageCount = function () {
        return Math.ceil(this.totalRecords / this.rows) || 1;
    };
    Paginator.prototype.calculatePageLinkBoundaries = function () {
        var numberOfPages = this.getPageCount(), visiblePages = Math.min(this.pageLinkSize, numberOfPages);
        //calculate range, keep current in middle if necessary
        var start = Math.max(0, Math.ceil(this.getPage() - ((visiblePages) / 2))), end = Math.min(numberOfPages - 1, start + visiblePages - 1);
        //check when approaching to last page
        var delta = this.pageLinkSize - (end - start + 1);
        start = Math.max(0, start - delta);
        return [start, end];
    };
    Paginator.prototype.updatePageLinks = function () {
        this.pageLinks = [];
        var boundaries = this.calculatePageLinkBoundaries(), start = boundaries[0], end = boundaries[1];
        for (var i = start; i <= end; i++) {
            this.pageLinks.push(i + 1);
        }
    };
    Paginator.prototype.setRecordsText = function () {
        var p = this.getPage();
        var startNo = 0;
        var endNo;
        var size = this.rows;
        if (p || this._totalRecords) {
            startNo = p * size + 1;
        }
        if (this._totalRecords < (p + 1) * size)
            endNo = this._totalRecords;
        else
            endNo = (p + 1) * size;
        this._recordsText = startNo + " - " + endNo + " of " + this._totalRecords + " Timesheets";
        return this._recordsText;
    };
    Paginator.prototype.changePage = function (p) {
        var pc = this.getPageCount();
        if (p >= 0 && p < pc) {
            this.first = this.rows * p;
            var state = {
                page: p,
                first: this.first,
                rows: this.rows,
                pageCount: pc
            };
            this.updatePageLinks();
            this.onPageChange.emit(state);
        }
    };
    Paginator.prototype.getPage = function () {
        return Math.floor(this.first / this.rows);
    };
    Paginator.prototype.changePageToFirst = function () {
        this.changePage(0);
    };
    Paginator.prototype.changePageToPrev = function () {
        this.changePage(this.getPage() - 1);
    };
    Paginator.prototype.changePageToNext = function () {
        this.changePage(this.getPage() + 1);
    };
    Paginator.prototype.changePageToLast = function () {
        this.changePage(this.getPageCount() - 1);
    };
    Paginator.prototype.onRppChange = function (event) {
        this.rows = this.rowsPerPageOptions[event.target.selectedIndex];
        this.changePageToFirst();
    };
    __decorate([
        core_1.Input(), 
        __metadata('design:type', Number)
    ], Paginator.prototype, "rows", void 0);
    __decorate([
        core_1.Input(), 
        __metadata('design:type', Number)
    ], Paginator.prototype, "pageLinkSize", void 0);
    __decorate([
        core_1.Output(), 
        __metadata('design:type', core_1.EventEmitter)
    ], Paginator.prototype, "onPageChange", void 0);
    __decorate([
        core_1.Input(), 
        __metadata('design:type', Object)
    ], Paginator.prototype, "style", void 0);
    __decorate([
        core_1.Input(), 
        __metadata('design:type', String)
    ], Paginator.prototype, "styleClass", void 0);
    __decorate([
        core_1.Input(), 
        __metadata('design:type', String)
    ], Paginator.prototype, "pageTitle", void 0);
    __decorate([
        core_1.Input(), 
        __metadata('design:type', Array)
    ], Paginator.prototype, "rowsPerPageOptions", void 0);
    __decorate([
        core_1.Input(), 
        __metadata('design:type', Number)
    ], Paginator.prototype, "totalRecords", null);
    __decorate([
        core_1.Input(), 
        __metadata('design:type', Number)
    ], Paginator.prototype, "first", null);
    Paginator = __decorate([
        core_1.Component({
            selector: 'p-paginator',
            template: "      \n\t\t<div class=\"grid-section grid-section-no-border\">\n   <div class=\"col-lg-4 col-md-4 col-sm-12 col-xs-12 padL0 hidden-xs\">\n      <button type=\"submit\" class=\"btn btn-primary\"  disabled=\"\" >Submit</button>\n   </div>\n   <!-- Table Pagination Start Style 5 (new 1) -->\n   <div  class=\"custom-pagination col-lg-8 col-lg-offset-0 col-md-8 col-md-offset-0 col-sm-12 col-sm-offset-0 col-xs-12 padR0\">\n      <div class=\"clearfix\">\n         <div class=\"bottom\">\n            <div class=\"custom-pagination dataTables_length\">\n               <div class=\"custom-pagination-detail col-lg-6 col-md-6 col-sm-12 col-xs-12 margin-t-8 text-center pad0\" *ngIf=\"!rowsPerPageOptions\">                 \n      \n                         <span >\n                    \t {{ setRecordsText()}}  \n                \t\t  </span>                                   \n               </div>\n                 <div class=\"custom-pagination-detail col-lg-6 col-md-6 col-sm-12 col-xs-12 margin-t-8 text-center pad0\" *ngIf=\"rowsPerPageOptions\"> \n                 \t<ul class=\"list-inline margin-b-0\" *ngIf=\"rowsPerPageOptions && totalRecords > rowsPerPageOptions[0] \">\n\t\t\t\t\t\t<li class=\"col-lg-offset-3 col-lg-3 col-md-3\">\n\t\t\t\t\t\t\t<div class=\"universal-select drop-down\">\n\t\t\t\t\t\t\t\t<select class=\"form-control\" *ngIf=\"rowsPerPageOptions\" (change)=\"onRppChange($event)\">\n                           \t\t\t<option *ngFor=\"let opt of rowsPerPageOptions\" [value]=\"opt\" [selected]=\"rows == opt\">{{opt}}</option>\n                           \t\t</select>\n\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t</li>\n\t\t\t\t\t\t<li class=\"col-lg-3 col-md-3\"><p class=\"margin-t-5 text-left\">Per Page</p></li>\n\t\t\t\t\t</ul>\n               \t</div>  \n               <div class=\"custom-pagination-option col-lg-6 col-md-6 col-sm-12 col-xs-12 margin-t-8 pad0\">\n                  <ul class=\"list-inline hidden-md hidden-lg custom-pagination-list margin-l-0 margin-b-0\"  *ngIf=\" totalRecords > 0 \" >\n                     <li class=\"pad-0\">\n                        <span #prevlink  (mouseenter)=\"hoveredItem = $event.target\" \t(mouseleave)=\"hoveredItem = null\"      (click)=\"changePageToPrev()\"  class=\"hidden-xs\" [ngClass]=\"{'custom-toggle-close':isFirstPage(),'ui-state-hover':(prevlink === hoveredItem && !isFirstPage())}\"><a>&lt; Previous</a> &nbsp; </span>\n                        <span class=\"hidden-lg hidden-md hidden-sm\">\n                        <i class=\"fa fa-chevron-left\" (click)=\"changePageToPrev()\" aria-hidden=\"true\"></i>\n                        </span>\n                        <span  class=\"text-theme\">Page {{getPage()+1}} of {{getPageCount()}}  </span>\n                        <span #nextlink class=\"hidden-xs\" (mouseenter)=\"hoveredItem = $event.target\" (mouseleave)=\"hoveredItem = null\"                (click)=\"changePageToNext()\" [ngClass]=\"{'custom-toggle-close':isLastPage(),'ui-state-hover':(nextlink === hoveredItem  && !isLastPage())}\"> &nbsp; <a>Next &gt;</a></span>\n                        <span class=\"hidden-lg hidden-md hidden-sm\">\n                        <i class=\"fa fa-chevron-right\" (click)=\"changePageToNext()\" aria-hidden=\"true\"></i>\n                        </span>\t\t\t\t\t\t\n                     </li>\n                  </ul>\n                  \n                  <ul class=\"list-inline text-right hidden-sm hidden-xs custom-pagination-list margin-l-0 margin-b-0\"  *ngIf=\" totalRecords > 0 \" >\n                     <li>\n                        <span #prevlink  (mouseenter)=\"hoveredItem = $event.target\" \t(mouseleave)=\"hoveredItem = null\"      (click)=\"changePageToPrev()\"  class=\"hidden-xs\" [ngClass]=\"{'custom-toggle-close':isFirstPage(),'ui-state-hover':(prevlink === hoveredItem && !isFirstPage())}\"><a>&lt; Previous</a> &nbsp; </span>\n                        <span class=\"hidden-lg hidden-md hidden-sm\">\n                        <i class=\"fa fa-chevron-left\" (click)=\"changePageToPrev()\" aria-hidden=\"true\"></i>\n                        </span>\n                        <span  class=\"text-theme\">Page {{getPage()+1}} of {{getPageCount()}}  </span>\n                        <span #nextlink class=\"hidden-xs\" (mouseenter)=\"hoveredItem = $event.target\" (mouseleave)=\"hoveredItem = null\"                (click)=\"changePageToNext()\" [ngClass]=\"{'custom-toggle-close':isLastPage(),'ui-state-hover':(nextlink === hoveredItem  && !isLastPage())}\"> &nbsp; <a>Next &gt;</a></span>\n                        <span class=\"hidden-lg hidden-md hidden-sm\">\n                        <i class=\"fa fa-chevron-right\" (click)=\"changePageToNext()\" aria-hidden=\"true\"></i>\n                        </span>\t\t\t\t\t\t\n                     </li>\n                  </ul>\n                  \n               </div>\n            </div>\n         </div>\n      </div>\n   </div>\n   <!-- Table Pagination End Style 5 (new 1) -->\n   <div class=\"col-lg-4 col-md-4 col-sm-12 col-xs-12 margin-t-10 padL0 hidden-lg hidden-md hidden-sm\">\n      <button type=\"submit\" class=\"btn btn-primary\" disabled=\"!checkAll.itemsSelected.length &gt; 0\" >Submit</button>\n   </div>\n</div>\n\n    "
        }), 
        __metadata('design:paramtypes', [])
    ], Paginator);
    return Paginator;
}());
exports.Paginator = Paginator;
var PaginatorModule = (function () {
    function PaginatorModule() {
    }
    PaginatorModule = __decorate([
        core_1.NgModule({
            imports: [common_1.CommonModule],
            exports: [Paginator],
            declarations: [Paginator]
        }), 
        __metadata('design:paramtypes', [])
    ], PaginatorModule);
    return PaginatorModule;
}());
exports.PaginatorModule = PaginatorModule;
//# sourceMappingURL=paginator.js.map