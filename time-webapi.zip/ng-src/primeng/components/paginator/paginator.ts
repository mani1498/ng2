import {NgModule,Component,ElementRef,Input,Output,SimpleChange,EventEmitter} from '@angular/core';
import {CommonModule} from '@angular/common';

@Component({
    selector: 'p-paginator',
    template: `      
		<div class="grid-section grid-section-no-border">
   <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 padL0 hidden-xs">
      <button type="submit" class="btn btn-primary"  disabled="" >Submit</button>
   </div>
   <!-- Table Pagination Start Style 5 (new 1) -->
   <div  class="custom-pagination col-lg-8 col-lg-offset-0 col-md-8 col-md-offset-0 col-sm-12 col-sm-offset-0 col-xs-12 padR0">
      <div class="clearfix">
         <div class="bottom">
            <div class="custom-pagination dataTables_length">
               <div class="custom-pagination-detail col-lg-6 col-md-6 col-sm-12 col-xs-12 margin-t-8 text-center pad0" *ngIf="!rowsPerPageOptions">                 
      
                         <span >
                    	 {{ setRecordsText()}}  
                		  </span>                                   
               </div>
                 <div class="custom-pagination-detail col-lg-6 col-md-6 col-sm-12 col-xs-12 margin-t-8 text-center pad0" *ngIf="rowsPerPageOptions"> 
                 	<ul class="list-inline margin-b-0" *ngIf="rowsPerPageOptions && totalRecords > rowsPerPageOptions[0] ">
						<li class="col-lg-offset-3 col-lg-3 col-md-3">
							<div class="universal-select drop-down">
								<select class="form-control" *ngIf="rowsPerPageOptions" (change)="onRppChange($event)">
                           			<option *ngFor="let opt of rowsPerPageOptions" [value]="opt" [selected]="rows == opt">{{opt}}</option>
                           		</select>
							</div>
						</li>
						<li class="col-lg-3 col-md-3"><p class="margin-t-5 text-left">Per Page</p></li>
					</ul>
               	</div>  
               <div class="custom-pagination-option col-lg-6 col-md-6 col-sm-12 col-xs-12 margin-t-8 pad0">
                  <ul class="list-inline hidden-md hidden-lg custom-pagination-list margin-l-0 margin-b-0"  *ngIf=" totalRecords > 0 " >
                     <li class="pad-0">
                        <span #prevlink  (mouseenter)="hoveredItem = $event.target" 	(mouseleave)="hoveredItem = null"      (click)="changePageToPrev()"  class="hidden-xs" [ngClass]="{'custom-toggle-close':isFirstPage(),'ui-state-hover':(prevlink === hoveredItem && !isFirstPage())}"><a>&lt; Previous</a> &nbsp; </span>
                        <span class="hidden-lg hidden-md hidden-sm">
                        <i class="fa fa-chevron-left" (click)="changePageToPrev()" aria-hidden="true"></i>
                        </span>
                        <span  class="text-theme">Page {{getPage()+1}} of {{getPageCount()}}  </span>
                        <span #nextlink class="hidden-xs" (mouseenter)="hoveredItem = $event.target" (mouseleave)="hoveredItem = null"                (click)="changePageToNext()" [ngClass]="{'custom-toggle-close':isLastPage(),'ui-state-hover':(nextlink === hoveredItem  && !isLastPage())}"> &nbsp; <a>Next &gt;</a></span>
                        <span class="hidden-lg hidden-md hidden-sm">
                        <i class="fa fa-chevron-right" (click)="changePageToNext()" aria-hidden="true"></i>
                        </span>						
                     </li>
                  </ul>
                  
                  <ul class="list-inline text-right hidden-sm hidden-xs custom-pagination-list margin-l-0 margin-b-0"  *ngIf=" totalRecords > 0 " >
                     <li>
                        <span #prevlink  (mouseenter)="hoveredItem = $event.target" 	(mouseleave)="hoveredItem = null"      (click)="changePageToPrev()"  class="hidden-xs" [ngClass]="{'custom-toggle-close':isFirstPage(),'ui-state-hover':(prevlink === hoveredItem && !isFirstPage())}"><a>&lt; Previous</a> &nbsp; </span>
                        <span class="hidden-lg hidden-md hidden-sm">
                        <i class="fa fa-chevron-left" (click)="changePageToPrev()" aria-hidden="true"></i>
                        </span>
                        <span  class="text-theme">Page {{getPage()+1}} of {{getPageCount()}}  </span>
                        <span #nextlink class="hidden-xs" (mouseenter)="hoveredItem = $event.target" (mouseleave)="hoveredItem = null"                (click)="changePageToNext()" [ngClass]="{'custom-toggle-close':isLastPage(),'ui-state-hover':(nextlink === hoveredItem  && !isLastPage())}"> &nbsp; <a>Next &gt;</a></span>
                        <span class="hidden-lg hidden-md hidden-sm">
                        <i class="fa fa-chevron-right" (click)="changePageToNext()" aria-hidden="true"></i>
                        </span>						
                     </li>
                  </ul>
                  
               </div>
            </div>
         </div>
      </div>
   </div>
   <!-- Table Pagination End Style 5 (new 1) -->
   <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 margin-t-10 padL0 hidden-lg hidden-md hidden-sm">
      <button type="submit" class="btn btn-primary" disabled="!checkAll.itemsSelected.length &gt; 0" >Submit</button>
   </div>
</div>

    `
})
export class Paginator {

    @Input() rows: number = 0;

    @Input() pageLinkSize: number = 5;

    @Output() onPageChange: EventEmitter<any> = new EventEmitter();

    @Input() style: any;

    @Input() styleClass: string;
	
	@Input() pageTitle: string;
    
    @Input() rowsPerPageOptions: number[];

    pageLinks: number[];

    _totalRecords: number = 0;
	
	_recordsText: string;
    
    _first: number = 0;
    
    
    

    @Input() get totalRecords(): number {
        return this._totalRecords;
    }

    set totalRecords(val:number) {
        this._totalRecords = val;
        this.updatePageLinks();
    }
    
	
	
    @Input() get first(): number {
        return this._first;
    }

    set first(val:number) {
        this._first = val;
        this.updatePageLinks();
    }

    isFirstPage() {
        return this.getPage() === 0;
    }

    isLastPage() {
        return this.getPage() === this.getPageCount() - 1;
    }

    getPageCount() {
        return Math.ceil(this.totalRecords/this.rows)||1;
    }

    calculatePageLinkBoundaries() {
        let numberOfPages = this.getPageCount(),
        visiblePages = Math.min(this.pageLinkSize, numberOfPages);

        //calculate range, keep current in middle if necessary
        let start = Math.max(0, Math.ceil(this.getPage() - ((visiblePages) / 2))),
        end = Math.min(numberOfPages - 1, start + visiblePages - 1);

        //check when approaching to last page
        var delta = this.pageLinkSize - (end - start + 1);
        start = Math.max(0, start - delta);

        return [start, end];
    }
    
    updatePageLinks() {
        this.pageLinks = [];
        let boundaries = this.calculatePageLinkBoundaries(),
        start = boundaries[0],
        end = boundaries[1];

        for(let i = start; i <= end; i++) {
            this.pageLinks.push(i + 1);
        }
    }
	
	setRecordsText(){
	 let p = this.getPage() ;	
	 let startNo:number  =0 ;
	 let endNo :number;
	 let size = this.rows;
	 	
	   if( p  || this._totalRecords )
	   {
		startNo = p* size + 1;				
	   }
	   
	  if( this._totalRecords <    (p+1) * size  )
	  endNo = this._totalRecords ;
	  else
	  endNo = (p+1) * size  ;	
	  
	  
	  this._recordsText  = startNo + " - " + endNo  + " of "+ this._totalRecords + " Timesheets"    ;
	   return this._recordsText;
	}
	
    changePage(p :number) {
        var pc = this.getPageCount();

        if(p >= 0 && p < pc) {
            this.first = this.rows * p;
            var state = {
                page: p,
                first: this.first,
                rows: this.rows,
                pageCount: pc
            };
            this.updatePageLinks();

            this.onPageChange.emit(state);
        }

    }
    
    getPage(): number {
        return Math.floor(this.first / this.rows);
    }

    changePageToFirst() {
		
        this.changePage(0);
    }

    changePageToPrev() {
        this.changePage(this.getPage() - 1);
    }

    changePageToNext() {
        this.changePage(this.getPage()  + 1);
    }

    changePageToLast() {
        this.changePage(this.getPageCount() - 1);
    }
    
    onRppChange(event) {
        this.rows = this.rowsPerPageOptions[event.target.selectedIndex];
        this.changePageToFirst();
    }
}

@NgModule({
    imports: [CommonModule],
    exports: [Paginator],
    declarations: [Paginator]
})
export class PaginatorModule { }
