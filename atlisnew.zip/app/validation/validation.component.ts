import {Component,OnInit}  from '@angular/core';
import {FORM_DIRECTIVES} from '@angular/common';
import {Router,ROUTER_DIRECTIVES } from '@angular/router';


@Component({
    selector : 'val-app',
    templateUrl: './app/validation/val.html',
    directives: [FORM_DIRECTIVES,ROUTER_DIRECTIVES]
})

export class ValidationComponent{
    private message;
    private data = {};
	firstValReq: boolean;
	secondValReq: boolean;
	decimalValReq: boolean;
	inValidDecimalVal: boolean;
	compareStatus:boolean;
	
    constructor(  private router: Router) {}
	
	onSubmit(f){
		if (f.form.value.firstVal == null || f.form.value.secondVal == null){
			this.firstValReq= f.form.value.firstVal == null ? true : false;
			this.secondValReq= f.form.value.secondVal == null ? true : false;
			this.decimalValReq= f.form.value.decimalVal == null ? true : false;
			return false;
		}else{
			this.compareStatus= f.form.value.firstVal <=  f.form.value.secondVal ? true : false;
			return false;
		}
    }
	
	decVal(val){
		if (!val.match(/^\d{0,2}(\.\d{1,2})?$/)) {
            this.inValidDecimalVal = true ;
        } else {
            this.inValidDecimalVal = false ;
        }
	}
	
    get diagnostic() { return JSON.stringify(this.data); }
}