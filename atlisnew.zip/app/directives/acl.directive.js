/*
import { Directive, ViewContainerRef, ResolvedReflectiveProvider } from '@angular/core';
import { Router,RouterOutlet,RouterOutletMap,ActivatedRoute  } from '@angular/router';

@Directive({
    selector: 'router-outlet'
})
export class AclDirective extends RouterOutlet {
    private parentRouter: Router;
    constructor(parentOutletMap: RouterOutletMap, _location: ViewContainerRef, name: string) {
        //super(parentOutletMap, _location, name);
    }

    activate(activatedRoute: ActivatedRoute, providers: ResolvedReflectiveProvider[], outletMap: RouterOutletMap){
        super.activate(activatedRoute, providers, outletMap);

       /!*!// let loginService: LoginService = hostInjector().get(LoginService);
        console.log(this.loginService);
        //router.navigate(['HomeCMP']);
       // super.activate(activatedRoute, providers, outletMap);
        if(activatedRoute.url.value[0].path == 'login'){
            super.activate(activatedRoute, providers, outletMap);
        }else{
            this.parentRouter.navigate(['login']);
            //super.activate(activatedRoute, providers, outletMap);
          // window.location.href="/login";// this.router.navigate(['Login']);
        }*!/
    }
}*/
//# sourceMappingURL=acl.directive.js.map