import {Component}  from '@angular/core';
import { ROUTER_DIRECTIVES } from '@angular/router';

@Component({
    selector : 'region',
    templateUrl: './views/region/region.html',
    directives: [ROUTER_DIRECTIVES]
})

export class RegionComponent{

}

@Component({
    selector : 'region-list',
    templateUrl: './views/region/list.html',
    directives: [ROUTER_DIRECTIVES]
})

export class RegionListComponent{

}

@Component({
    selector : 'region-edit',
    templateUrl: './views/region/edit.html',
    directives: [ROUTER_DIRECTIVES]
})

export class RegionEditComponent{
    
}