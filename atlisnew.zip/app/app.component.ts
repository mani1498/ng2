import { Component } from '@angular/core';
import { ROUTER_DIRECTIVES } from '@angular/router';

import { LoginService } from './services/login.service';
//import { AclDirective } from './directives/acl.directive';

@Component({
    selector: 'atlis-app',
    template: '<div class="main-layout-outlet"><router-outlet></router-outlet></div>',
    directives: [ROUTER_DIRECTIVES],
    providers: [
        LoginService
    ]
})

export class AppComponent { }