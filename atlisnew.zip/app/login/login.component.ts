import {Component,OnInit}  from '@angular/core';
import {FORM_DIRECTIVES} from '@angular/common';
import {Router,ROUTER_DIRECTIVES } from '@angular/router';
import {LoginService} from "../services/login.service";


@Component({
    selector : 'login-app',
    templateUrl: './app/login/login.html',
    directives: [FORM_DIRECTIVES,ROUTER_DIRECTIVES]
})

export class LoginComponent{
    private message;
    private data = {};
	
	invEmail: boolean;
	emVal: boolean;
	psVal: boolean;

    constructor( private loginService: LoginService, private router: Router) {}

    onClickMe(){
        this.message="clicked";
    }
	onSubmit(f){
		if (f.form.value.email == null || f.form.value.password == null){console.log('a');
		  return false;
		}else{
			if (f.form.value.email.match(/[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/)) {
			console.log('b');
					this.loginService.login(f.form.value.email, f.form.value.password).subscribe((result) => {
						if (result.access_token) {console.log('c');
							this.router.navigate(['validation']);
						}
					});
			}else{console.log('d');
				this.invEmail=true;
				return false;
			}
		}
    }
	
	formStatus(e,p){
		this.invEmail=false;
		this.emVal= e == null ? true : false;
		this.psVal= p == null ? true : false;
	}
    get diagnostic() { return JSON.stringify(this.data); }
}