"use strict";
var router_1 = require('@angular/router');
var login_component_1 = require('../login/login.component');
var home_component_1 = require('../home/home.component');
var validation_component_1 = require('../validation/validation.component');
var region_component_1 = require('../region/region.component');
var routes = [
    {
        path: '',
        component: login_component_1.LoginComponent, data: { 'id': 88 }
    },
    {
        path: 'login',
        component: login_component_1.LoginComponent, data: { 'id': 86 }
    },
    {
        path: 'validation',
        component: validation_component_1.ValidationComponent, data: { 'id': 86 }
    },
    {
        path: 'settings',
        component: home_component_1.HomeComponent,
        children: [
            { path: '', component: region_component_1.RegionComponent },
            { path: 'region', component: region_component_1.RegionComponent, data: { 'id': 56 },
                children: [
                    { path: '', component: region_component_1.RegionListComponent, data: { 'id': 76 } },
                    { path: 'edit', component: region_component_1.RegionEditComponent, data: { 'id': 86 } }
                ]
            }
        ]
    }
];
exports.appRouterProviders = [
    router_1.provideRouter(routes)
];
//# sourceMappingURL=app.routes.js.map