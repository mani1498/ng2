import { provideRouter, RouterConfig } from '@angular/router';

import {LoginComponent} from '../login/login.component';
import {HomeComponent} from '../home/home.component';
import {ValidationComponent} from '../validation/validation.component';
import {RegionComponent,RegionListComponent,RegionEditComponent} from '../region/region.component';


const routes: RouterConfig = [
    {
        path: '',
        component: LoginComponent, data : {'id':88}
    },
    {
        path: 'login',
        component: LoginComponent, data : {'id':86}
    },
	{
        path: 'validation',
        component: ValidationComponent, data : {'id':86}
    },
    {
        path: 'settings',
        component: HomeComponent,
        children: [
            { path: '', component: RegionComponent }, //settings link redirect to region
            { path: 'region', component: RegionComponent, data : {'id':56},
                children: [
                    { path: '', component: RegionListComponent, data : {'id':76} },
                    { path: 'edit', component: RegionEditComponent, data : {'id':86} }
                ]
            }
        ]
    }
];

export const appRouterProviders = [
    provideRouter(routes)
];
