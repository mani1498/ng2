import { Injectable }    from '@angular/core';
import { Http, Response,Headers } from '@angular/http';

@Injectable()
export class LoginService {

    private loggedIn = false;
    constructor(private http: Http) {
        this.loggedIn = !!window.localStorage.getItem('auth_token');
    }
    login(email,password){
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        return this.http
            .get(
                '/app/mock/login.json',
                { headers }
            )
            .map((res:Response) => res.json())
            .map((res) => {
                if (res.access_token) {
                    window.localStorage.setItem('auth_token', res.access_token);
                    this.loggedIn = true;
                }
                return res;
            });
    }
    logout() {
        window.localStorage.removeItem('auth_token');
        this.loggedIn = false;
    }

    isLoggedIn() {
        return this.loggedIn;
    }
}
