import {Component,OnInit}  from '@angular/core';
import { REACTIVE_FORM_DIRECTIVES, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ControlMessages } from './control-messages.component';
import { ValidationService } from './validation.service';
import {ROUTER_DIRECTIVES, Router } from '@angular/router';

@Component({
    selector : 'login-app',
    templateUrl: './app/login/login.html',
    styleUrls: ['css/app.css'],
    directives: [REACTIVE_FORM_DIRECTIVES,ROUTER_DIRECTIVES,ControlMessages]
})

export class LoginComponent{

userForm: any;
  
  constructor(private formBuilder: FormBuilder,  public router: Router) {
      
    this.userForm = this.formBuilder.group({
      'email': ['', [Validators.required, ValidationService.emailValidator]],
      'password': ['', [Validators.required, Validators.minLength(6)]]
    });
  }
  
  saveUser() {
    if (this.userForm.dirty && this.userForm.valid) {
      alert(`Password: ${this.userForm.value.password} Email: ${this.userForm.value.email}`);
      this.router.navigate(['/region']);
    }
    else
    console.log('no');
  }


}