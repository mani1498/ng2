import { provideRouter, Router, RouterConfig, ROUTER_DIRECTIVES } from '@angular/router';

import {LoginComponent} from '../login/login.component';
import {RegionComponent} from '../region/region.component';

const routes: RouterConfig = [
    {
        path: '',
        component: LoginComponent
    },
    {
        path: 'login',
        component: LoginComponent
    },
    {
        path: 'region',
        component: RegionComponent
    }
];

export const appRouterProviders = [
    provideRouter(routes)
];
