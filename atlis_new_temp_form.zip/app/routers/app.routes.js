"use strict";
var router_1 = require('@angular/router');
var login_component_1 = require('../login/login.component');
var region_component_1 = require('../region/region.component');
var routes = [
    {
        path: '',
        component: login_component_1.LoginComponent
    },
    {
        path: 'login',
        component: login_component_1.LoginComponent
    },
    {
        path: 'region',
        component: region_component_1.RegionComponent
    }
];
exports.appRouterProviders = [
    router_1.provideRouter(routes)
];
//# sourceMappingURL=app.routes.js.map