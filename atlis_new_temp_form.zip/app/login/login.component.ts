import {Component,OnInit}  from '@angular/core';
import {FORM_DIRECTIVES} from '@angular/common';
import {ROUTER_DIRECTIVES } from '@angular/router';

@Component({
    selector : 'login-app',
    templateUrl: './app/login/login.html',
    styleUrls: ['css/app.css'],
    directives: [FORM_DIRECTIVES,ROUTER_DIRECTIVES]
})

export class LoginComponent{
    private message;
    private data = {};
    onClickMe(){
        this.message="clicked";
    }
    onSubmit(f){
        console.log(f)
    }
	
	formStatus(e,p){
		this.emVal= e == null ? true : false;
		this.psVal= p == null ? true : false;
	}
    get diagnostic() { return JSON.stringify(this.data); }
}