import {Component}  from '@angular/core';

@Component({
    selector : 'region',
    templateUrl: './views/region/regionList.html'
})

export class RegionComponent{

}