import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {FileUploadModule} from 'primeng/primeng';
import { AppComponent }  from './app.component';
import { FileUploadComponent }  from './file.component';

@NgModule({
  imports: [ BrowserModule,FileUploadModule ],
  declarations: [ AppComponent,FileUploadComponent ],
  bootstrap: [ AppComponent ]
})
export class AppModule { }
