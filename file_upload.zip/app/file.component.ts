import {Component,OnInit,Input,Output,EventEmitter,TemplateRef,AfterContentInit,ContentChildren,QueryList} from '@angular/core';
import {DomSanitizer} from '@angular/platform-browser';
@Component({
  selector: 'file-upload',
  template: '<input type="file" accept="image/*" (change)="onFileSelect($event)" />'
})
export class FileUploadComponent {
  //@Output() onSelectDone = new EventEmitter();
  protected files: File[];

  @Output() onSelectDone: EventEmitter<any> = new EventEmitter();

  constructor(private sanitizer: DomSanitizer){}
  ngOnInit() {
    this.files = [];
  }
  onFileSelect(event) {
    let files = event.dataTransfer ? event.dataTransfer.files : event.target.files;
    for (let i = 0; i < files.length; i++) {
      let file = files[i];
      if (this.isImage(file)) {
        file.objectURL = this.sanitizer.bypassSecurityTrustUrl((window.URL.createObjectURL(files[i])));
      }

      this.files.push(files[i]);
    }
    this.onSelectDone.emit({originalEvent: event, files: files});
  }
  isImage(file: File): boolean {
    return /^image\//.test(file.type);
  }


}
