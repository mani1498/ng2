"use strict";
exports.ENVIRONMENTS = {
    mock: true,
    service: false,
    serviceUrl: 'http://localhost:8089/timetrack/'
};
exports.PTO = [
    { reason: "Vacation" },
    { reason: "Sick" },
    { reason: "Jury Duty" },
    { reason: "Bereavement" }
];
//# sourceMappingURL=config.js.map