export interface ConfigEnvironment{
    mock: boolean;
    service: boolean;
    serviceUrl:string;
}

export interface PTOConfig{
    reason: string;
}