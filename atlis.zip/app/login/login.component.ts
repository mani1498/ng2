import {Component,OnInit}  from '@angular/core';
import {FORM_DIRECTIVES} from '@angular/common';
import {ROUTER_DIRECTIVES } from '@angular/router';

@Component({
    selector : 'login-app',
    templateUrl: './app/login/login.html',
    styleUrls: ['css/app.css'],
    directives: [FORM_DIRECTIVES,ROUTER_DIRECTIVES]
})

export class LoginComponent{
    private message;
    private data = {};

    onClickMe(){
        this.message="clicked";
    }
    onSubmit(){
        console.log('comes')
    }
    get diagnostic() { return JSON.stringify(this.data); }
}