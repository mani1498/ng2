"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var AppComponent = (function () {
    function AppComponent(el) {
        this.el = el;
        this.timesheetDetailsSummary = {
            "timeSheetId": 26,
            "status": "Awaiting Approval",
            "previousTsId": "",
            "nextTsId": "",
            "totalHours": null,
            "fdate": "Mon Sep 12, 2016",
            "tdate": "Sun Sep 18, 2016",
            "fdatetDate": "Mon Sep 12, 2016 - Sun Sep 18, 2016"
        };
        this.notSubmittedPtoTimevalues = [{
                "timeOffType": "Holiday",
                "day1": "3.0",
                "day2": "1.0",
                "day3": "0",
                "day4": "0",
                "day5": "0",
                "day6": "0",
                "day7": "0",
                "day1PtoRequestId": 103,
                "day2PtoRequestId": 192,
                "day3PtoRequestId": 0,
                "day4PtoRequestId": 0,
                "day5PtoRequestId": 0,
                "day6PtoRequestId": 0,
                "day7PtoRequestId": 0,
                "day1Comment": "ptotype",
                "day2Comment": "fdsf",
                "day3Comment": "fdsf",
                "day4Comment": "fdsf",
                "day5Comment": "fdsf",
                "day6Comment": "fdsf",
                "day7Comment": "fdsf",
                "total": 4.0
            }];
        this.ptoTypesConfig = ["Vacation", "Sick", "Jury Duty", "Bereavement"];
        this.el = el.nativeElement;
        console.log('df', this.notSubmittedPtoTimevalues);
    }
    AppComponent.prototype.ngOnInit = function () {
    };
    /*****   PTO Changes By Mani ***********/
    AppComponent.prototype.selectPto = function (selectedPto, rootObj, ptoCount) {
        if (this.ptoTypesConfig.length > 0) {
            console.log('selectedPto', this.ptoTypesConfig);
            this.notSubmittedPtoTimevalues[rootObj].timeOffType = selectedPto;
            this.ptoTypesConfig.splice(ptoCount, 1);
            var selValue = this.selectedPtoValue;
            var ptoTypesConfigArr = this.ptoTypesConfig;
            if (typeof selValue != 'undefined' && selValue != "Select") {
                if (ptoTypesConfigArr.indexOf(selValue) < 0)
                    ptoTypesConfigArr.push(selValue);
                this.ptoTypesConfig = ptoTypesConfigArr;
            }
            console.log('selectedPtoNew', this.ptoTypesConfig);
        }
    };
    AppComponent.prototype.enablePopover = function (selectedPtoValue) {
        if (selectedPtoValue != 'Select') {
            console.log('exisitingPtoValue', selectedPtoValue);
            this.selectedPtoValue = selectedPtoValue;
        }
    };
    AppComponent.prototype.deleteptos = function (ptotype, ptoid) {
        this.notSubmittedPtoTimevalues.splice(ptoid, 1);
        if (this.notSubmittedPtoTimevalues.indexOf(ptotype) < 0) {
            this.ptoTypesConfig.push(ptotype);
        }
    };
    AppComponent.prototype.addPto = function () {
        this.notSubmittedPtoTimevalues.push({
            "timeOffType": "Select",
            "day1": "0.4",
            "day2": "23.0",
            "day3": "5.0",
            "day4": "2.0",
            "day5": "3.0 ",
            "day6 ": "3.0 ",
            "day7 ": "3.0 ",
            "day1PtoRequestId ": 99,
            "day2PtoRequestId ": 106,
            "day3PtoRequestId ": 109,
            "day4PtoRequestId ": 110,
            "day5PtoRequestId": 111,
            "day6PtoRequestId": 112,
            "day7PtoRequestId": 113,
            "day1Comment": "test pto 22",
            "day2Comment": "Test",
            "day3Comment": "Test",
            "day4Comment": "Tes",
            "day5Comment": "Mani comment",
            "day6Comment": "pto type comment",
            "day7Comment": "pto type ccc",
            "total": 39.4,
            "type": "new"
        });
    };
    AppComponent = __decorate([
        core_1.Component({
            selector: 'my-app',
            templateUrl: './app/popover.html'
        }), 
        __metadata('design:paramtypes', [core_1.ElementRef])
    ], AppComponent);
    return AppComponent;
}());
exports.AppComponent = AppComponent;
//# sourceMappingURL=app.component.js.map