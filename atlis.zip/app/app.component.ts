import { Component, ElementRef} from '@angular/core';
import {Router} from '@angular/router';
declare  var $:any;
@Component({
    selector: 'my-app',
    templateUrl:'./app/popover.html'
})
export class AppComponent {
	public timesheetDetailsSummary={
			"timeSheetId": 26,
			"status": "Awaiting Approval",
			"previousTsId": "",
			"nextTsId": "",
			"totalHours": null,
			"fdate": "Mon Sep 12, 2016",
			"tdate": "Sun Sep 18, 2016",
			"fdatetDate": "Mon Sep 12, 2016 - Sun Sep 18, 2016"
		};	
	public notSubmittedPtoTimevalues=[{
			"timeOffType": "Holiday",
			"day1": "3.0",
			"day2": "1.0",
			"day3": "0",
			"day4": "0",
			"day5": "0",
			"day6": "0",
			"day7": "0",
			"day1PtoRequestId": 103,
			"day2PtoRequestId": 192,
			"day3PtoRequestId": 0,
			"day4PtoRequestId": 0,
			"day5PtoRequestId": 0,
			"day6PtoRequestId": 0,
			"day7PtoRequestId": 0,
			"day1Comment": "ptotype",
			"day2Comment": "fdsf",
			"day3Comment": "fdsf",
			"day4Comment": "fdsf",
			"day5Comment": "fdsf",
			"day6Comment": "fdsf",
			"day7Comment": "fdsf",
			"total": 4.0
		}];
public selectedPtoValue:string;
public ptoTypesConfig = ["Vacation","Sick","Jury Duty","Bereavement"];




    constructor(private el: ElementRef) {
        this.el = el.nativeElement;
		console.log('df',this.notSubmittedPtoTimevalues);
    }

    ngOnInit(): void {
      
    }

    /*****   PTO Changes By Mani ***********/

    selectPto(selectedPto:string,rootObj:number,ptoCount:number){
        if(this.ptoTypesConfig.length > 0){
			console.log('selectedPto',this.ptoTypesConfig);
            this.notSubmittedPtoTimevalues[rootObj].timeOffType=selectedPto;
            this.ptoTypesConfig.splice(ptoCount,1);
			let selValue=this.selectedPtoValue;
			let ptoTypesConfigArr=this.ptoTypesConfig;
			if(typeof selValue != 'undefined' && selValue !="Select"){
				if(ptoTypesConfigArr.indexOf(selValue) < 0)
					ptoTypesConfigArr.push(selValue);
				this.ptoTypesConfig=ptoTypesConfigArr;
			}
			
			console.log('selectedPtoNew',this.ptoTypesConfig);
        }
    }

    enablePopover(selectedPtoValue:string){
        if(selectedPtoValue != 'Select'){
            console.log('exisitingPtoValue',selectedPtoValue);
            this.selectedPtoValue=selectedPtoValue;
        }
    }
	
	deleteptos(ptotype:string,ptoid:number){
        this.notSubmittedPtoTimevalues.splice(ptoid,1);
		if(this.notSubmittedPtoTimevalues.indexOf(ptotype) < 0){
			this.ptoTypesConfig.push(ptotype);
		}
	}
    addPto(){
       this.notSubmittedPtoTimevalues.push({
			"timeOffType": "Select",
			"day1": "0.4",
			"day2": "23.0",
			"day3": "5.0",
			"day4": "2.0",
			"day5": "3.0 ",
			"day6 ": "3.0 ",
			"day7 ": "3.0 ",
			"day1PtoRequestId ": 99,
			"day2PtoRequestId ": 106,
			"day3PtoRequestId ": 109,
			"day4PtoRequestId ": 110,
			"day5PtoRequestId": 111,
			"day6PtoRequestId": 112,
			"day7PtoRequestId": 113,
			"day1Comment": "test pto 22",
			"day2Comment": "Test",
			"day3Comment": "Test",
			"day4Comment": "Tes",
			"day5Comment": "Mani comment",
			"day6Comment": "pto type comment",
			"day7Comment": "pto type ccc",
			"total": 39.4,
			"type":"new"
			});
        }
    }
	
}
