import { Injectable }    from '@angular/core';
import { Headers, RequestOptions, Http } from '@angular/http';
import 'rxjs/add/operator/toPromise';
import {Observable} from 'rxjs/Observable';

@Injectable()

export class HttpClient {
    constructor(private http: Http) { }

    get(url:string) {
        return this.http.get(url)
            .toPromise()
            .then(response => response.json());
    }   
    
}
