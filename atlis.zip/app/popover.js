"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var router_1 = require('@angular/router');
var TimesheetViewComponent = (function () {
    function TimesheetViewComponent(router, el) {
        this.router = router;
        this.el = el;
        this.notSubmittedPtoTimevalues = [{
                "timeOffType": "Jury Duty",
                "day1": "3.0",
                "day2": "1.0",
                "day3": "0",
                "day4": "0",
                "day5": "0",
                "day6": "0",
                "day7": "0",
                "day1PtoRequestId": 103,
                "day2PtoRequestId": 192,
                "day3PtoRequestId": 0,
                "day4PtoRequestId": 0,
                "day5PtoRequestId": 0,
                "day6PtoRequestId": 0,
                "day7PtoRequestId": 0,
                "day1Comment": "ptotype",
                "day2Comment": "fdsf",
                "day3Comment": "fdsf",
                "day4Comment": "fdsf",
                "day5Comment": "fdsf",
                "day6Comment": "fdsf",
                "day7Comment": "fdsf",
                "total": 4.0
            }];
        this.ptoTypesConfig = [
            { reason: "Vacation" },
            { reason: "Sick" },
            { reason: "Jury Duty" },
            { reason: "Bereavement" }
        ];
        this.el = el.nativeElement;
    }
    TimesheetViewComponent.prototype.ngOnInit = function () {
    };
    /*****   PTO Changes By Mani ***********/
    TimesheetViewComponent.prototype.selectPto = function (selectedPto, rootObj, ptoCount) {
        console.log('df', this.ptoTypesConfig);
        if (this.ptoTypesConfig.length > 0) {
            $('.popover').hide();
            this.notSubmittedPtoTimevalues[rootObj].timeOffType = selectedPto;
            this.ptoTypesConfig.splice(ptoCount, 1);
        }
    };
    TimesheetViewComponent.prototype.enablePopover = function (selectedPtoValue) {
        console.log('ttt333', selectedPtoValue);
        if (selectedPtoValue != 'Select') {
            console.log('ttt', selectedPtoValue);
            this.selectedPtoValue = selectedPtoValue;
        }
        $('.popover').show();
    };
    TimesheetViewComponent.prototype.addPto = function () {
        this.notSubmittedPtoTimevalues.push({
            "timeOffType": "Vacation",
            "day1": "0.4",
            "day2": "23.0",
            "day3": "5.0",
            "day4": "2.0",
            "day5": "3.0 ",
            "day6 ": "3.0 ",
            "day7 ": "3.0 ",
            "day1PtoRequestId ": 99,
            "day2PtoRequestId ": 106,
            "day3PtoRequestId ": 109,
            "day4PtoRequestId ": 110,
            "day5PtoRequestId": 111,
            "day6PtoRequestId": 112,
            "day7PtoRequestId": 113,
            "day1Comment": "test pto 22",
            "day2Comment": "Test",
            "day3Comment": "Test",
            "day4Comment": "Tes",
            "day5Comment": "Mani comment",
            "day6Comment": "pto type comment",
            "day7Comment": "pto type ccc",
            "total": 39.4
        });
    };
    TimesheetViewComponent = __decorate([
        core_1.Component({
            selector: 'timesheet',
            templateUrl: './popover.html'
        }), 
        __metadata('design:paramtypes', [router_1.Router, core_1.ElementRef])
    ], TimesheetViewComponent);
    return TimesheetViewComponent;
}());
exports.TimesheetViewComponent = TimesheetViewComponent;
deletepto(ptotype, string, ptoid, number);
{
    console.log('ptotype', ptotype);
    this.notSubmittedPtoTimevalues.splice(ptoid, 1);
    //console.log('removedPtoTypes',this.removedPtoTypes);
    this.ptoTypesConfig.push({ "reason": ptotype });
}
//# sourceMappingURL=popover.js.map