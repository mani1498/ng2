import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {PopoverModule} from "./src/index";
import { AppComponent }  from './app.component';
import { FormsModule }   from '@angular/forms';

@NgModule({
  imports: [ BrowserModule,PopoverModule,FormsModule],
  declarations: [ AppComponent ],
  bootstrap: [ AppComponent ]
})
export class AppModule { }
