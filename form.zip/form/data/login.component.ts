import {Component,OnInit}  from '@angular/core';
import {FORM_DIRECTIVES} from '@angular/common';
import {ROUTER_DIRECTIVES } from '@angular/router';
import {FormBuilder } from '@angular/common';
import {ControlGroup } from '@angular/common';
import {Validators } from '@angular/common';


@Component({
    selector : 'login-app',
    templateUrl: './app/login/login.html',
    styleUrls: ['css/app.css'],
    directives: [FORM_DIRECTIVES,ROUTER_DIRECTIVES]
})

export class LoginComponent implements OnInit{
	myForm : ControlGroup;
	user = {email: '',password: ''};
	
	constructor(private formBuilder: FormBuilder){}
	
	ngOnInit():any{
		this.myForm = this.formBuilder.group({
				'email':['',Validators.required],
				'password':['',Validators.compose([
					Validators.required,
					hasNumbers				
				])],
		});
	}
	
    private message;
    private data = {};

    onClickMe(){
        this.message="clicked";
    }
    onSubmit(f){
        console.log('comes')
    }
    get diagnostic() { return JSON.stringify(this.data); }
}

function hasNumbers(control: Control):{[s: string]: boolean}{
	console.log(control.value);
	if(!control.value.match('\\d+')){

		return {noNumbers:true};
	}
}